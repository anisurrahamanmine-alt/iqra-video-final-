import React from 'react';
import { Audio, interpolate, Sequence, staticFile } from 'remotion';
import { SFX_LEN } from './data/sfxLen';

// Semantic SFX map (user's Sound_Effects_SFX.zip, renamed ASCII + normalised to -3 dBFS peak; synth_* made in tools/synth_sfx.py)
export const SFXMAP = {
  whoosh: ['whoosh_a.mp3', 'whoosh_b.mp3', 'whoosh_c.mp3', 'whoosh_d.mp3'],
  whooshCine: ['whoosh_cine.mp3', 'whoosh_cine2.mp3'],
  pop: ['pop_a.mp3', 'pop_b.mp3', 'pop_c.mp3'],
  paper: ['paper.mp3', 'paper_slide.mp3', 'page_flip.mp3', 'page_turn.mp3', 'book_open.mp3'],
  marker: ['marker.mp3'],
  tick: ['synth_tick.wav', 'key_click.mp3', 'digital_click.mp3'],
  stamp: ['thud_heavy.mp3', 'thud_ground.mp3', 'impact_hit.mp3'],
  boom: ['boom_cine.mp3', 'boom_suspense.mp3'],
  riser: ['synth_riser_soft.wav', 'riser.mp3', 'riser_paper.mp3', 'riser_swoosh.mp3'],
  chime: ['synth_chime_soft.wav', 'ding.mp3', 'bell.mp3', 'shine.mp3', 'twinkle.mp3', 'correct.mp3'],
  ui: ['ui_tap.mp3', 'ui_click.mp3'],
  slash: ['synth_slash.wav', 'scratch.mp3'],
  swell: ['synth_swell.wav'],
} as const;

export type SfxCue = { at: number; f: string; v?: number; len?: number; rate?: number; fadeTo?: number };
/** cue helper: frame, file, volume (voice = 1.0), optional cut length */
export const sx = (at: number, f: string, v = 0.3, len?: number): SfxCue => ({ at, f, v, len });

export const SfxTrack: React.FC<{ cues: SfxCue[] }> = ({ cues }) => (
  <>
    {cues.map((c, i) => {
      const len = c.len ?? SFX_LEN[c.f] ?? 60;
      // after the attention-grabbing intro, every cue sits a step lower under the voice
      const v = (c.v ?? 0.2) * (c.at < 150 ? 1 : 0.85);
      return (
        <Sequence key={i} from={Math.max(0, c.at)} durationInFrames={len} layout="none">
          <Audio src={staticFile('sfx/' + c.f)} playbackRate={c.rate ?? 1}
            volume={(f) => {
              const a = Math.min(6, len * 0.3), b = Math.max(a + 1, len - Math.min(c.len ? 10 : 2, len * 0.4));
              return interpolate(f, [0, a, b, len], [v, c.fadeTo ?? v, c.fadeTo ?? v, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
            }} />
        </Sequence>
      );
    })}
  </>
);
