import React from 'react';
import { AbsoluteFill, Audio, Sequence, staticFile } from 'remotion';
import { DURATION, OVERLAP, SCENES } from './config';
import { useFonts } from './fonts';
import { SfxTrack } from './sfx';
import { AnimatedGridBg } from './components/AnimatedGridBg';
import { CameraRig } from './components/CameraRig';
import { DustMotes } from './components/Atmos';
import { KineticCaptionBar } from './components/KineticCaptionBar';
import * as Sc from './scenes';

const LIST: React.FC[] = [Sc.Scene01, Sc.Scene02, Sc.Scene03, Sc.Scene04, Sc.Scene05, Sc.Scene06, Sc.Scene07, Sc.Scene08, Sc.Scene09, Sc.Scene10, Sc.Scene11];

export const Main: React.FC = () => {
  useFonts();
  return (
    <AbsoluteFill style={{ background: '#FAF9F5' }}>
      <AnimatedGridBg />
      <CameraRig layer="mid">
        {SCENES.map((s, i) => {
          const Comp = LIST[i];
          const dur = Math.min(DURATION, s.to + OVERLAP) - s.from;
          return (
            <Sequence key={s.id} from={s.from} durationInFrames={dur} name={`Scene${String(s.id).padStart(2, '0')}`}>
              <Comp />
            </Sequence>
          );
        })}
      </CameraRig>
      <CameraRig layer="fg"><DustMotes /></CameraRig>
      <KineticCaptionBar />
      <SfxTrack cues={Sc.ALL_SFX} />
      <Audio src={staticFile('audio/voiceover.mp3')} volume={1} />
    </AbsoluteFill>
  );
};
