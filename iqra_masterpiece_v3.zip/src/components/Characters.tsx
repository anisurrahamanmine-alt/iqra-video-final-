import React from 'react';
import { C } from '../theme';

// Layered flat 2D people (ordinary modern viewers/learners — never sacred figures).
const SKIN = '#C98E64';
const SKIN_D = '#B07A52';
const HAIR = '#2B2220';

const Arm: React.FC<{ x: number; y: number; a1: number; a2: number; sleeve: string; front?: React.ReactNode }> = ({ x, y, a1, a2, sleeve, front }) => (
  <g transform={`translate(${x} ${y}) rotate(${a1})`}>
    <rect x={-15} y={-6} width={30} height={92} rx={15} fill={sleeve} />
    <g transform={`translate(0 80) rotate(${a2})`}>
      <rect x={-13} y={-6} width={26} height={78} rx={13} fill={sleeve} />
      <circle cx={0} cy={76} r={16} fill={SKIN} />
      {front}
    </g>
  </g>
);

export type PersonPose = { tilt?: number; turn?: number; aL1?: number; aL2?: number; aR1?: number; aR2?: number; bob?: number };

export const Person: React.FC<{ w?: number; pose: PersonPose; shirt?: string; variant?: 'man' | 'hijab'; blindfold?: number; eyesUp?: boolean; holdR?: React.ReactNode; holdL?: React.ReactNode; under?: React.ReactNode }> = ({ w = 300, pose, shirt = C.teal, variant = 'man', blindfold = 0, eyesUp, holdR, holdL, under }) => {
  const { tilt = 0, turn = 0, aL1 = 12, aL2 = -6, aR1 = -12, aR2 = 6, bob = 0 } = pose;
  const h = w * 1.45;
  const eyeY = eyesUp ? 102 : 108;
  return (
    <svg width={w} height={h} viewBox="0 0 300 435" style={{ overflow: 'visible' }}>
      <ellipse cx={150} cy={428} rx={110} ry={12} fill={C.navy} opacity={0.12} />
      <g transform={`translate(0 ${bob})`}>
        {under}
        {/* torso */}
        <path d="M150 168 Q92 172 84 214 L74 430 H226 L216 214 Q208 172 150 168Z" fill={shirt} />
        <path d="M150 168 L136 200 L150 214 L164 200Z" fill="#FFFFFF" opacity={0.85} />
        {/* back arm (viewer's left) */}
        <Arm x={98} y={196} a1={aL1} a2={aL2} sleeve={shirt} front={holdL} />
        {/* neck */}
        <rect x={136} y={140} width={28} height={36} rx={12} fill={SKIN_D} />
        {/* head */}
        <g transform={`rotate(${tilt} 150 150)`}>
          {variant === 'hijab' ? (
            <>
              <path d="M150 50 Q94 52 92 112 Q92 160 116 178 L184 178 Q208 160 208 112 Q206 52 150 50Z" fill={C.navy} />
              <ellipse cx={150 + turn * 6} cy={112} rx={40} ry={46} fill={SKIN} />
              <path d="M110 92 Q150 60 190 92 Q180 70 150 66 Q120 70 110 92Z" fill={C.navy} />
            </>
          ) : (
            <>
              <ellipse cx={150 + turn * 6} cy={110} rx={44} ry={50} fill={SKIN} />
              <path d={`M${104 + turn * 6} 104 Q${104 + turn * 6} 56 ${150 + turn * 6} 56 Q${198 + turn * 6} 56 ${196 + turn * 6} 100 Q${176 + turn * 6} 82 ${140 + turn * 6} 84 Q${118 + turn * 6} 86 ${104 + turn * 6} 104Z`} fill={HAIR} />
              <ellipse cx={104 + turn * 4} cy={114} rx={7} ry={11} fill={SKIN_D} />
              <ellipse cx={196 + turn * 4} cy={114} rx={7} ry={11} fill={SKIN_D} />
            </>
          )}
          {blindfold > 0 ? (
            <g opacity={blindfold}>
              <rect x={100 + turn * 6} y={94} width={100} height={24} rx={8} fill={C.ruby} />
              <path d={`M${100 + turn * 6} 104 l-22 18 l8 4 l18 -14z`} fill={C.ruby} />
            </g>
          ) : (
            <>
              <ellipse cx={134 + turn * 9} cy={eyeY} rx={4.5} ry={5.5} fill={C.navy} />
              <ellipse cx={166 + turn * 9} cy={eyeY} rx={4.5} ry={5.5} fill={C.navy} />
              <path d={`M${126 + turn * 9} ${eyeY - 14} q8 -5 16 0 M${158 + turn * 9} ${eyeY - 14} q8 -5 16 0`} stroke={HAIR} strokeWidth={4} fill="none" strokeLinecap="round" />
            </>
          )}
          <path d={`M${140 + turn * 9} 136 q10 ${blindfold > 0 ? -4 : 7} 20 0`} stroke={C.navy} strokeWidth={4} fill="none" strokeLinecap="round" />
        </g>
        {/* front arm (viewer's right) */}
        <Arm x={202} y={196} a1={aR1} a2={aR2} sleeve={shirt} front={holdR} />
      </g>
    </svg>
  );
};
