import React from 'react';
import { rnd } from '../anim';
import { C } from '../theme';

/** Serene editorial ink-and-gouache Jabal al-Nour with the empty rocky arch of Cave Hira, lit from above. No figures. */
export const HiraArt: React.FC<{ F: number; w?: number; h?: number; beam: number }> = ({ F, w = 820, h = 480, beam }) => {
  const par = (k: number) => Math.sin(F / 140) * 10 * k;
  return (
    <svg width={w} height={h} viewBox="0 0 820 480" style={{ display: 'block', borderRadius: 14 }}>
      <defs>
        <linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#E9ECFB" /><stop offset="0.55" stopColor="#FBF1D9" /><stop offset="1" stopColor="#F8E3B8" /></linearGradient>
        <linearGradient id="hbeam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#FFF6CF" stopOpacity="0.95" /><stop offset="1" stopColor="#FFF6CF" stopOpacity="0" /></linearGradient>
        <linearGradient id="hrock" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#3B4A66" /><stop offset="1" stopColor="#1C2840" /></linearGradient>
        <filter id="ink" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves={2} seed={4} /><feDisplacementMap in="SourceGraphic" scale={6} /></filter>
        <radialGradient id="hglow" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#FFF1C2" stopOpacity="0.9" /><stop offset="1" stopColor="#FFF1C2" stopOpacity="0" /></radialGradient>
      </defs>
      <rect width={820} height={480} fill="url(#hsky)" />
      {/* geometric starlight */}
      {Array.from({ length: 9 }).map((_, i) => <circle key={i} cx={60 + rnd(i) * 700} cy={30 + rnd(i + 20) * 110} r={1.6 + rnd(i + 5) * 1.6} fill={C.goldDeep} opacity={0.3 + 0.3 * Math.sin((F + i * 30) / 25)} />)}
      {/* far ridges */}
      <g transform={`translate(${par(0.3)} 0)`} filter="url(#ink)">
        <path d="M-20 330 L90 250 L170 290 L260 220 L360 300 L460 240 L560 300 L680 230 L840 310 V480 H-20Z" fill="#B9C7D6" opacity={0.7} />
        <path d="M-20 370 L120 300 L230 340 L330 290 L450 350 L600 300 L720 340 L840 320 V480 H-20Z" fill="#8FA3BA" opacity={0.75} />
      </g>
      {/* main mountain with cave arch */}
      <g transform={`translate(${par(0.7)} 0)`} filter="url(#ink)">
        <path d="M150 480 L300 230 L370 150 L430 120 L500 170 L560 240 L700 480Z" fill="url(#hrock)" />
        <path d="M300 230 L370 150 L400 200 L340 260Z" fill="#4B5C7C" opacity={0.6} />
        {/* rocky arch: two leaning rocks + empty cave mouth */}
        <path d="M392 262 Q404 206 448 196 Q492 204 500 262 L486 300 L408 300Z" fill="#0E1626" />
        <path d="M380 300 Q384 240 420 204 L438 210 Q406 246 404 300Z" fill="#56688A" />
        <path d="M512 300 Q506 236 460 200 L444 210 Q484 246 490 300Z" fill="#46587A" />
        <path d="M372 300 H520 L540 330 H350Z" fill="#2A3854" />
      </g>
      {/* top-down light beam into the cave */}
      <g opacity={beam}>
        <path d="M410 0 L486 0 L510 300 L384 300Z" fill="url(#hbeam)" />
        <ellipse cx={447} cy={292} rx={70} ry={20} fill="url(#hglow)" />
        {Array.from({ length: 14 }).map((_, i) => {
          const y = ((rnd(i + 3) * 300 + F * (0.3 + rnd(i) * 0.4)) % 300);
          return <circle key={i} cx={412 + rnd(i + 11) * 72 + Math.sin((F + i * 20) / 30) * 4} cy={y} r={1.4 + rnd(i + 2) * 1.8} fill="#FFF8DC" opacity={0.75} />;
        })}
      </g>
      <rect width={820} height={480} fill="none" stroke={C.goldDeep} strokeOpacity={0.35} strokeWidth={2} rx={14} />
    </svg>
  );
};
