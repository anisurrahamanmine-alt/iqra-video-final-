import React from 'react';
import { idle, lin, sp } from '../anim';
import { C, SHADOW } from '../theme';

// "যিনি সবকিছু সৃষ্টি করেছেন" — small, clean creation icons (sun, moon, earth, planet, stars, mountain, tree, water)
const Sun: React.FC<{ F: number }> = ({ F }) => (
  <svg width={60} height={60} viewBox="0 0 100 100">
    <g transform={`rotate(${F * 1.2} 50 50)`} stroke="#F59E0B" strokeWidth={7} strokeLinecap="round">
      {Array.from({ length: 8 }).map((_, i) => <line key={i} x1={50} y1={6} x2={50} y2={18} transform={`rotate(${i * 45} 50 50)`} />)}
    </g>
    <circle cx={50} cy={50} r={23} fill="#FBBF24" /><circle cx={50} cy={50} r={23} fill="none" stroke="#F59E0B" strokeWidth={3} />
  </svg>
);
const Moon: React.FC<{ F: number }> = ({ F }) => (
  <svg width={60} height={60} viewBox="0 0 100 100"><g transform={`rotate(${Math.sin(F / 20) * 8} 50 50)`}><path d="M60 12 A38 38 0 1 0 88 70 A30 30 0 1 1 60 12Z" fill="#6D7FD1" /></g></svg>
);
const Earth: React.FC<{ F: number }> = ({ F }) => (
  <svg width={60} height={60} viewBox="0 0 100 100">
    <defs><clipPath id="ec"><circle cx={50} cy={50} r={38} /></clipPath></defs>
    <circle cx={50} cy={50} r={38} fill="#38BDF8" />
    <g clipPath="url(#ec)" transform={`translate(${((F * 0.8) % 76) - 38} 0)`} fill="#10B981">
      {[0, 76].map((o) => <g key={o} transform={`translate(${o} 0)`}><path d="M20 30 q14 -10 24 2 q4 10 -8 14 q-10 6 -16 -4z" /><path d="M48 58 q16 -6 20 8 q-2 14 -14 12 q-10 -6 -6 -20z" /><path d="M-4 60 q10 -4 14 6 q-6 10 -14 4z" /></g>)}
    </g>
    <circle cx={50} cy={50} r={38} fill="none" stroke="#0E7490" strokeWidth={3} />
  </svg>
);
const Planet: React.FC<{ F: number }> = ({ F }) => (
  <svg width={62} height={62} viewBox="0 0 100 100">
    <g transform={`rotate(${-18 + Math.sin(F / 25) * 6} 50 50)`}>
      <path d="M8 54 Q50 76 92 54" fill="none" stroke="#C084FC" strokeWidth={6} strokeLinecap="round" />
      <circle cx={50} cy={50} r={24} fill="#A855F7" />
      <path d="M30 42 h40 M28 54 h44" stroke="#E9D5FF" strokeWidth={4} opacity={0.6} />
      <path d="M8 54 Q50 32 92 54" fill="none" stroke="#C084FC" strokeWidth={6} strokeLinecap="round" opacity={0.0} />
      <path d="M26 46 Q50 38 74 46" fill="none" stroke="#C084FC" strokeWidth={0} />
    </g>
  </svg>
);
const Stars: React.FC<{ F: number }> = ({ F }) => (
  <svg width={60} height={60} viewBox="0 0 100 100">
    {[[50, 46, 26, 0], [22, 24, 12, 1], [80, 76, 13, 2], [76, 20, 9, 3]].map(([x, y, r, k]) => (
      <g key={k} transform={`translate(${x} ${y}) scale(${(r / 26) * (0.85 + 0.15 * Math.sin(F / 6 + k * 2))})`} fill="#F59E0B">
        <path d="M0 -26 L7 -7 L26 0 L7 7 L0 26 L-7 7 L-26 0 L-7 -7Z" />
      </g>
    ))}
  </svg>
);
const Mountain: React.FC = () => (
  <svg width={64} height={60} viewBox="0 0 100 90">
    <path d="M4 84 L38 26 L54 50 L66 34 L96 84Z" fill="#3F5C8A" />
    <path d="M38 26 L48 43 L42 40 L34 46 L30 40Z" fill="#FFFFFF" /><path d="M66 34 L74 47 L66 44 L60 46Z" fill="#FFFFFF" />
  </svg>
);
const Tree: React.FC<{ F: number }> = ({ F }) => (
  <svg width={58} height={62} viewBox="0 0 90 100">
    <rect x={40} y={60} width={10} height={34} rx={3} fill="#92400E" />
    <g transform={`rotate(${Math.sin(F / 14) * 4} 45 94)`}>
      <circle cx={45} cy={36} r={24} fill="#10B981" /><circle cx={28} cy={52} r={17} fill="#059669" /><circle cx={62} cy={52} r={17} fill="#059669" />
    </g>
  </svg>
);
const Water: React.FC<{ F: number }> = ({ F }) => (
  <svg width={64} height={60} viewBox="0 0 100 90">
    <path d="M50 6 Q72 34 72 50 a22 22 0 0 1 -44 0 Q28 34 50 6Z" fill="#38BDF8" />
    <path d="M40 50 a10 10 0 0 0 10 10" stroke="#FFFFFF" strokeWidth={4} fill="none" strokeLinecap="round" />
    {[0, 1].map((k) => <path key={k} d={`M${6 + ((F * 0.6 + k * 30) % 20)} ${80 + k * 6} q10 -6 20 0 t20 0 t20 0 t20 0`} stroke="#0EA5E9" strokeWidth={4} fill="none" strokeLinecap="round" opacity={0.7} />)}
  </svg>
);

const ITEMS = ['sun', 'moon', 'earth', 'planet', 'stars', 'mountain', 'tree', 'water'] as const;

export const CreationRow: React.FC<{ F: number; at: number; step?: number }> = ({ F, at, step = 4 }) => (
  <div style={{ display: 'flex', gap: 12, padding: '12px 18px', borderRadius: 999, background: 'rgba(255,254,250,.92)', border: `1.5px solid ${C.goldDeep}44`, boxShadow: SHADOW.soft, opacity: lin(F, at - 4, at + 2) }}>
    {ITEMS.map((k, i) => {
      const t = at + i * step;
      const p = sp(F, t, 'pop');
      return (
        <div key={k} style={{ width: 86, height: 86, borderRadius: 43, background: ['#FFF7E0', '#EEF0FF', '#E6F7FB', '#F5EDFF', '#FFF7E0', '#EAF0F8', '#E8F8F1', '#E6F5FD'][i], display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: lin(F, t, t + 5), transform: `translateY(${24 * (1 - p) + idle(F, i, 2.5, 46 + i * 4)}px) scale(${0.4 + 0.6 * p})` }}>
          {k === 'sun' && <Sun F={F} />}
          {k === 'moon' && <Moon F={F} />}
          {k === 'earth' && <Earth F={F} />}
          {k === 'planet' && <Planet F={F} />}
          {k === 'stars' && <Stars F={F} />}
          {k === 'mountain' && <Mountain />}
          {k === 'tree' && <Tree F={F} />}
          {k === 'water' && <Water F={F} />}
        </div>
      );
    })}
  </div>
);
