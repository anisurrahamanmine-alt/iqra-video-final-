import React from 'react';
import { lin, ramp, sp } from '../anim';
import { C, FONT } from '../theme';
import { ManuscriptFrame } from './Card';

export const VERSE = [
  { w: 'اقْرَأْ', at: 1600 },
  { w: 'بِاسْمِ', at: 1611 },
  { w: 'رَبِّكَ', at: 1624 },
  { w: 'الَّذِي', at: 1640 },
  { w: 'خَلَقَ', at: 1654 },
];

/** Surah Al-Alaq 96:1 — RTL Arabic with word-by-word warm-gold illumination, Tiro Bangla translation, citation strip */
export const SacredVerseCard: React.FC<{ F: number; at: number; trAt: number; sweepAt: number; line2At: number; citeAt: number }> = ({ F, at, trAt, sweepAt, line2At, citeAt }) => {
  const p = sp(F, at, 'soft');
  const reveal = ramp(F, at + 2, at + 16);
  const glow = 0.4 + 0.25 * Math.sin(F / 18);
  const tr = sp(F, trAt, 'soft');
  const sweep = ramp(F, sweepAt, sweepAt + 30);
  const l2 = sp(F, line2At, 'soft');
  const cite = sp(F, citeAt, 'snap');
  return (
    <div style={{ opacity: lin(F, at, at + 8), transform: `translateY(${80 * (1 - p)}px) scale(${0.92 + 0.08 * p})` }}>
      <ManuscriptFrame w={880} pad={54} glow={glow * ramp(F, at, at + 20)} style={{ paddingBottom: 110 }}>
        {/* Arabic verse, RTL */}
        <div dir="rtl" lang="ar" style={{ unicodeBidi: 'embed', direction: 'rtl', display: 'flex', justifyContent: 'center', flexWrap: 'nowrap', gap: 22, fontFamily: FONT.arabic, fontSize: 84, lineHeight: 2.0, color: C.navy, clipPath: `inset(0 0 0 ${100 - reveal * 100}%)`, paddingTop: 6 }}>
          {VERSE.map((v, i) => {
            const lit = ramp(F, v.at - 1, v.at + 7);
            const next = VERSE[i + 1]?.at ?? v.at + 18;
            const active = F >= v.at - 1 && F < next + 4;
            return (
              <span key={i} style={{ position: 'relative', display: 'inline-block', padding: '0 10px', transform: `scale(${active ? 1.06 : 1})` }}>
                <span style={{ position: 'absolute', left: -6, right: -6, top: '22%', bottom: '18%', borderRadius: 26, background: `radial-gradient(ellipse at center, ${C.gold} 0%, ${C.gold}cc 45%, ${C.gold}00 75%)`, opacity: lit * (active ? 1 : 0.42) }} />
                <span style={{ position: 'relative', color: lit > 0.5 ? C.navy : '#3A4660' }}>{v.w}</span>
              </span>
            );
          })}
        </div>
        {/* ornamental divider */}
        <svg width={772} height={26} style={{ display: 'block', margin: '4px auto 18px', opacity: tr }}>
          <line x1={0} y1={13} x2={340} y2={13} stroke={C.goldDeep} strokeOpacity={0.5} strokeWidth={1.5} />
          <line x1={432} y1={13} x2={772} y2={13} stroke={C.goldDeep} strokeOpacity={0.5} strokeWidth={1.5} />
          <g transform="translate(386 13)" fill="none" stroke={C.goldDeep} strokeWidth={1.8}><rect x={-8} y={-8} width={16} height={16} /><rect x={-8} y={-8} width={16} height={16} transform="rotate(45)" /></g>
        </svg>
        {/* Bengali translation (Tiro Bangla) */}
        <div style={{ textAlign: 'center', fontFamily: FONT.serif, fontSize: 56, lineHeight: 1.45, color: C.ink }}>
          <div style={{ opacity: lin(F, trAt, trAt + 8), transform: `translateY(${26 * (1 - tr)}px)` }}>
            <span style={{ position: 'relative', display: 'inline-block' }}>
              <span style={{ position: 'absolute', left: -10, right: -10, top: '18%', bottom: '8%', background: C.gold, borderRadius: 10, transformOrigin: 'left', transform: `scaleX(${sweep})` }} />
              <span style={{ position: 'relative', color: C.navy }}>“পড়ো তোমার প্রতিপালকের নামে,</span>
            </span>
          </div>
          <div style={{ opacity: lin(F, line2At, line2At + 8), transform: `translateY(${26 * (1 - l2)}px)`, color: C.teal, fontWeight: 400 }}>যিনি সবকিছু সৃষ্টি করেছেন”</div>
        </div>
        {/* citation strip */}
        <div style={{ position: 'absolute', left: 30, right: 30, bottom: 26, height: 62, borderRadius: 14, background: C.navy, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, opacity: cite, transform: `translateY(${20 * (1 - cite)}px)` }}>
          <svg width={26} height={26} viewBox="0 0 100 100"><g transform="translate(50 50)" fill={C.gold}><rect x={-30} y={-30} width={60} height={60} /><rect x={-30} y={-30} width={60} height={60} transform="rotate(45)" /></g></svg>
          <span style={{ fontFamily: FONT.sans, fontWeight: 600, fontSize: 32, color: '#FFFFFF', letterSpacing: 0.3 }}>Surah Al-Alaq (96:1) — The First Revelation</span>
        </div>
      </ManuscriptFrame>
    </div>
  );
};
