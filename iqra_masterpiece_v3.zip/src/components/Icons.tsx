import React from 'react';
import { C } from '../theme';

type P = { size?: number; c?: string; p?: number; style?: React.CSSProperties; sw?: number };
const S: React.FC<{ size: number; vb?: string; style?: React.CSSProperties; children: React.ReactNode }> = ({ size, vb = '0 0 100 100', style, children }) => (
  <svg width={size} height={size} viewBox={vb} style={{ overflow: 'visible', ...style }}>{children}</svg>
);
const draw = (p = 1) => ({ pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - p });

export const Mosque: React.FC<P> = ({ size = 80, c = C.navy, style }) => (
  <S size={size} style={style}>
    <path d="M50 10 v8" stroke={c} strokeWidth={4} strokeLinecap="round" />
    <path d="M44 22 a7 7 0 1 0 9 -4 a5.5 5.5 0 1 1 -9 4z" fill={C.goldDeep} />
    <path d="M22 58 Q22 30 50 26 Q78 30 78 58 Z" fill={c} />
    <rect x={14} y={56} width={72} height={30} rx={3} fill={c} />
    <path d="M42 86 V70 a8 8 0 0 1 16 0 V86z" fill={C.gold} />
    <rect x={6} y={40} width={7} height={46} rx={2} fill={c} /><rect x={87} y={40} width={7} height={46} rx={2} fill={c} />
    <path d="M6 40 l3.5 -8 l3.5 8z M87 40 l3.5 -8 l3.5 8z" fill={c} />
  </S>
);
export const Crescent: React.FC<P> = ({ size = 80, c = C.teal, style }) => (
  <S size={size} style={style}>
    <path d="M62 14 A38 38 0 1 0 86 74 A30 30 0 1 1 62 14z" fill={c} />
    <path d="M74 30 l3 8 8 0 -6.5 5 2.5 8 -7 -5 -7 5 2.5 -8 -6.5 -5 8 0z" fill={C.goldDeep} />
  </S>
);
export const CharityHand: React.FC<P> = ({ size = 80, c = C.goldDeep, style }) => (
  <S size={size} style={style}>
    <circle cx={56} cy={26} r={14} fill={C.gold} stroke={c} strokeWidth={4} />
    <path d="M51 26 h10 M56 21 v10" stroke={c} strokeWidth={3.4} strokeLinecap="round" />
    <path d="M10 66 h16 q10 0 18 6 h18 q7 0 7 6 q0 6 -7 6 H44" fill="none" stroke={C.navy} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
    <path d="M26 84 l14 6 q6 2 12 0 l34 -16 q6 -4 2 -9 q-4 -4 -10 -1 l-20 10" fill="none" stroke={C.navy} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" />
  </S>
);
export const Shield: React.FC<P> = ({ size = 80, c = C.navy, style }) => (
  <S size={size} style={style}>
    <path d="M50 8 L84 20 V48 Q84 76 50 92 Q16 76 16 48 V20 Z" fill={c} />
    <path d="M36 50 L64 50" stroke={C.gold} strokeWidth={7} strokeLinecap="round" />
    <circle cx={50} cy={50} r={20} fill="none" stroke={C.gold} strokeWidth={5} />
  </S>
);
export const Question: React.FC<P> = ({ size = 80, c = C.goldDeep, style, sw = 9 }) => (
  <S size={size} style={style}>
    <path d="M32 34 Q32 14 50 14 Q68 14 68 32 Q68 44 56 50 Q50 54 50 64" fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" />
    <circle cx={50} cy={82} r={sw * 0.72} fill={c} />
  </S>
);
export const Cross: React.FC<P> = ({ size = 80, c = C.ruby, p = 1, style, sw = 11 }) => (
  <S size={size} style={style}>
    <path d="M18 18 L82 82" fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" {...draw(Math.min(1, p * 2))} />
    <path d="M82 18 L18 82" fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" {...draw(Math.max(0, p * 2 - 1))} />
  </S>
);
export const Check: React.FC<P> = ({ size = 80, c = C.teal, p = 1, style, sw = 11 }) => (
  <S size={size} style={style}>
    <path d="M16 54 L40 76 L86 24" fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" {...draw(p)} />
  </S>
);
/** single long strike for chips/bars */
export const Slash: React.FC<{ w: number; h?: number; p: number; c?: string; sw?: number }> = ({ w, h = 30, p, c = C.ruby, sw = 9 }) => (
  <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ overflow: 'visible' }}>
    <path d={`M6 ${h * 0.75} Q ${w * 0.5} ${h * 0.2} ${w - 6} ${h * 0.3}`} fill="none" stroke={c} strokeWidth={sw} strokeLinecap="round" {...draw(p)} />
  </svg>
);
export const BookOpen: React.FC<P & { open?: number; glow?: number }> = ({ size = 120, c = C.teal, open = 1, glow = 0, style }) => {
  const a = 1 - open; // 0 open, 1 closed
  return (
    <S size={size} vb="0 0 140 100" style={style}>
      {glow > 0 && <ellipse cx={70} cy={50} rx={70} ry={46} fill={C.gold} opacity={0.45 * glow} />}
      <g transform={`translate(70 0) scale(${1 - a * 0.5} 1) translate(-70 0)`}>
        <path d="M70 22 Q44 10 14 16 V84 Q44 78 70 90 Z" fill="#FFFDF5" stroke={c} strokeWidth={4} strokeLinejoin="round" />
        <path d="M70 22 Q96 10 126 16 V84 Q96 78 70 90 Z" fill="#FFFDF5" stroke={c} strokeWidth={4} strokeLinejoin="round" />
        {[0, 1, 2, 3].map((i) => <path key={i} d={`M24 ${32 + i * 12} Q44 ${28 + i * 12} 60 ${34 + i * 12}`} stroke={c} strokeOpacity={0.45} strokeWidth={3} fill="none" strokeLinecap="round" />)}
        {[0, 1, 2, 3].map((i) => <path key={i} d={`M80 ${34 + i * 12} Q96 ${28 + i * 12} 116 ${32 + i * 12}`} stroke={c} strokeOpacity={0.45} strokeWidth={3} fill="none" strokeLinecap="round" />)}
        <path d="M70 22 V90" stroke={c} strokeWidth={4} />
      </g>
    </S>
  );
};
export const BookClosed: React.FC<P> = ({ size = 80, c = C.teal, style }) => (
  <S size={size} style={style}>
    <rect x={20} y={10} width={60} height={80} rx={6} fill={c} />
    <rect x={26} y={16} width={48} height={68} rx={3} fill="none" stroke={C.gold} strokeWidth={2.4} />
    <g transform="translate(50 50)" fill="none" stroke={C.gold} strokeWidth={2.6}><rect x={-11} y={-11} width={22} height={22} /><rect x={-11} y={-11} width={22} height={22} transform="rotate(45)" /></g>
  </S>
);
export const ScrollSeal: React.FC<P> = ({ size = 80, c = C.navy, style }) => (
  <S size={size} style={style}>
    <rect x={18} y={14} width={64} height={64} rx={6} fill="#FFFBEF" stroke={c} strokeWidth={4} />
    <path d="M28 30 h44 M28 42 h44 M28 54 h28" stroke={c} strokeOpacity={0.5} strokeWidth={3.5} strokeLinecap="round" />
    <circle cx={70} cy={74} r={15} fill={C.goldDeep} />
    <g transform="translate(70 74)" fill="none" stroke="#FFF7DB" strokeWidth={2}><rect x={-6} y={-6} width={12} height={12} /><rect x={-6} y={-6} width={12} height={12} transform="rotate(45)" /></g>
  </S>
);
export const Pause: React.FC<P> = ({ size = 50, c = C.goldDeep, style }) => (
  <S size={size} style={style}>
    <circle cx={50} cy={50} r={44} fill="none" stroke={c} strokeWidth={6} />
    <rect x={34} y={30} width={10} height={40} rx={3} fill={c} /><rect x={56} y={30} width={10} height={40} rx={3} fill={c} />
  </S>
);
export const Lock: React.FC<P> = ({ size = 50, c = C.navy, style }) => (
  <S size={size} style={style}>
    <path d="M32 46 V32 a18 18 0 0 1 36 0 V46" fill="none" stroke={c} strokeWidth={8} />
    <rect x={22} y={44} width={56} height={44} rx={8} fill={c} />
    <circle cx={50} cy={64} r={6} fill={C.gold} />
  </S>
);
export const Compass: React.FC<P & { rot?: number; lock?: number }> = ({ size = 160, c = C.goldDeep, rot = 0, lock = 0, style }) => (
  <S size={size} style={style}>
    <circle cx={50} cy={50} r={46} fill="#FFFBEB" stroke={c} strokeWidth={3} />
    <circle cx={50} cy={50} r={38} fill="none" stroke={c} strokeOpacity={0.4} strokeWidth={1.5} strokeDasharray="2 4" />
    <g transform="translate(50 50)" fill="none" stroke={c} strokeOpacity={0.55} strokeWidth={1.4}><rect x={-14} y={-14} width={28} height={28} /><rect x={-14} y={-14} width={28} height={28} transform="rotate(45)" /></g>
    <g transform={`rotate(${rot} 50 50)`}>
      <path d="M50 10 L57 50 L50 46 L43 50 Z" fill={C.teal} />
      <path d="M50 90 L57 50 L50 54 L43 50 Z" fill={C.navy} opacity={0.85} />
    </g>
    <circle cx={50} cy={50} r={4.5} fill={c} />
    <circle cx={50} cy={50} r={46 + 10 * lock} fill="none" stroke={c} strokeWidth={3} opacity={lock > 0 ? 0.6 * (1 - lock) : 0} />
  </S>
);
export const Star8: React.FC<P> = ({ size = 40, c = C.goldDeep, style }) => (
  <S size={size} style={style}>
    <g transform="translate(50 50)" fill={c}><rect x={-30} y={-30} width={60} height={60} /><rect x={-30} y={-30} width={60} height={60} transform="rotate(45)" /></g>
    <circle cx={50} cy={50} r={14} fill="#FFFBEB" />
  </S>
);
export const ThumbUp: React.FC<P> = ({ size = 70, c = C.navy, style }) => (
  <S size={size} style={style}>
    <rect x={10} y={44} width={18} height={44} rx={4} fill={c} />
    <path d="M34 46 L52 14 q8 -4 10 6 l-4 20 h24 q10 2 8 12 l-7 30 q-3 8 -12 8 H34 Z" fill={c} />
  </S>
);
export const ShareIcon: React.FC<P> = ({ size = 70, c = C.white, style }) => (
  <S size={size} style={style}>
    <circle cx={74} cy={22} r={13} fill={c} /><circle cx={26} cy={50} r={13} fill={c} /><circle cx={74} cy={78} r={13} fill={c} />
    <path d="M37 44 L63 28 M37 56 L63 72" stroke={c} strokeWidth={7} strokeLinecap="round" />
  </S>
);
export const BellIcon: React.FC<P> = ({ size = 70, c = C.navy, style }) => (
  <S size={size} style={style}>
    <path d="M50 12 q24 0 26 26 v18 l10 14 H14 l10 -14 V38 q2 -26 26 -26z" fill={c} />
    <circle cx={50} cy={80} r={9} fill={c} />
  </S>
);
export const Cursor: React.FC<P> = ({ size = 70, style }) => (
  <S size={size} style={style}>
    <path d="M20 8 L20 78 L38 62 L50 90 L62 85 L50 58 L74 58 Z" fill={C.white} stroke={C.navy} strokeWidth={5} strokeLinejoin="round" />
  </S>
);
export const Spark: React.FC<P> = ({ size = 40, c = C.goldDeep, style }) => (
  <S size={size} style={style}><path d="M50 4 L58 42 L96 50 L58 58 L50 96 L42 58 L4 50 L42 42 Z" fill={c} /></S>
);
export const IdBadge: React.FC<P> = ({ size = 80, c = C.navy, style }) => (
  <S size={size} style={style}>
    <rect x={12} y={22} width={76} height={58} rx={9} fill={c} />
    <circle cx={34} cy={46} r={9} fill={C.gold} />
    <path d="M22 68 q12 -14 24 0" fill={C.gold} />
    <path d="M56 42 h22 M56 54 h16" stroke="#FFFFFF" strokeOpacity={0.8} strokeWidth={5} strokeLinecap="round" />
    <rect x={40} y={14} width={20} height={14} rx={4} fill={C.goldDeep} />
  </S>
);
