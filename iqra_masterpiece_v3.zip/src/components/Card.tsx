import React from 'react';
import { C, SHADOW } from '../theme';

/** crisp elevated ivory card with editorial corner marks */
export const Card: React.FC<{ children?: React.ReactNode; w?: number; h?: number; pad?: number; style?: React.CSSProperties; marks?: boolean; tone?: string }> = ({ children, w, h, pad = 36, style, marks = true, tone = C.card }) => (
  <div style={{ position: 'relative', width: w, height: h, padding: pad, background: tone, borderRadius: 20, border: `1.5px solid ${C.hair}`, boxShadow: SHADOW.card, boxSizing: 'border-box', ...style }}>
    {marks && [0, 1, 2, 3].map((i) => (
      <svg key={i} width={26} height={26} style={{ position: 'absolute', [i < 2 ? 'top' : 'bottom']: 10, [i % 2 === 0 ? 'left' : 'right']: 10, transform: `rotate(${[0, 90, 270, 180][i]}deg)` } as React.CSSProperties}>
        <path d="M2 18 V2 H18" fill="none" stroke={C.goldDeep} strokeOpacity={0.55} strokeWidth={2} />
      </svg>
    ))}
    {children}
  </div>
);

/** illuminated manuscript frame: gold geometric corner brackets */
export const ManuscriptFrame: React.FC<{ children?: React.ReactNode; w: number; h?: number; pad?: number; style?: React.CSSProperties; glow?: number }> = ({ children, w, h, pad = 44, style, glow = 0 }) => {
  const corner = (r: number, pos: React.CSSProperties) => (
    <svg width={74} height={74} viewBox="0 0 74 74" style={{ position: 'absolute', ...pos, transform: `rotate(${r}deg)` }}>
      <path d="M4 40 V4 H40" fill="none" stroke={C.goldDeep} strokeWidth={2.6} />
      <path d="M12 40 V12 H40" fill="none" stroke={C.goldDeep} strokeOpacity={0.5} strokeWidth={1.4} />
      <g transform="translate(22 22)" fill="none" stroke={C.goldDeep} strokeWidth={1.6}><rect x={-7} y={-7} width={14} height={14} /><rect x={-7} y={-7} width={14} height={14} transform="rotate(45)" /></g>
    </svg>
  );
  return (
    <div style={{ position: 'relative', width: w, height: h, padding: pad, boxSizing: 'border-box', background: `linear-gradient(180deg, #FFFEF9, #FFFBEF)`, borderRadius: 22, border: `1.5px solid ${C.goldDeep}55`, boxShadow: `${SHADOW.card}, 0 0 ${60 * glow}px rgba(253,230,138,${0.55 * glow})`, ...style }}>
      <div style={{ position: 'absolute', inset: 12, borderRadius: 14, border: `1px solid ${C.goldDeep}33` }} />
      {corner(0, { left: 6, top: 6 })}{corner(90, { right: 6, top: 6 })}{corner(270, { left: 6, bottom: 6 })}{corner(180, { right: 6, bottom: 6 })}
      {children}
    </div>
  );
};

/** absolute-positioned helper centred on x */
export const Abs: React.FC<{ x?: number; y: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ x = 540, y, children, style }) => (
  <div style={{ position: 'absolute', left: x, top: y, transform: 'translate(-50%, -50%)', width: 'max-content', maxWidth: 1000, display: 'flex', flexDirection: 'column', alignItems: 'center', ...style }}>{children}</div>
);
