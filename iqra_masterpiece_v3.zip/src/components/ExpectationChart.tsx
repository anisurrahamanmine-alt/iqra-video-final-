import React from 'react';
import { lin, ramp, sp } from '../anim';
import { C, FONT } from '../theme';
import { Card } from './Card';
import { CharityHand, Crescent, Cross, Mosque } from './Icons';

const ROWS = [
  { t: 'নামাজ', icon: Mosque, col: C.navy },
  { t: 'রোজা', icon: Crescent, col: C.teal },
  { t: 'যাকাত', icon: CharityHand, col: C.goldDeep },
];

/** "মানুষ যা ভাবে" — shared by Scene 1 (build) and Scene 2 (ruby strikes) at the same position */
export const ExpectationChart: React.FC<{ F: number; enterAt: number; barAts: number[]; crossAts?: number[]; headerAt?: number }> = ({ F, enterAt, barAts, crossAts = [], headerAt = enterAt }) => {
  const p = sp(F, enterAt, 'pop');
  return (
    <div style={{ opacity: lin(F, enterAt, enterAt + 8), transform: `translateY(${90 * (1 - p)}px) scale(${0.9 + 0.1 * p})` }}>
      <Card w={860} pad={44}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 26, opacity: lin(F, headerAt + 4, headerAt + 12) }}>
          <div style={{ width: 12, height: 44, borderRadius: 6, background: C.teal }} />
          <span style={{ fontFamily: FONT.sans, fontWeight: 700, fontSize: 46, color: C.navy }}>মানুষ যা ভাবে</span>
          <div style={{ flex: 1, height: 2, background: C.hair, marginLeft: 8 }} />
        </div>
        {ROWS.map((r, i) => {
          const at = barAts[i];
          const rp = sp(F, at, 'pop');
          const grow = ramp(F, at + 2, at + 26);
          const cp = crossAts[i] !== undefined ? ramp(F, crossAts[i], crossAts[i] + 9) : 0;
          const struck = cp > 0;
          const I = r.icon;
          return (
            <div key={i} style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 22, height: 132, opacity: lin(F, at, at + 6) * (struck ? 1 - 0.45 * cp : 1), transform: `translateX(${-60 * (1 - rp)}px)` }}>
              <div style={{ width: 104, height: 104, borderRadius: 26, background: `${r.col}14`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${0.6 + 0.4 * rp}) rotate(${Math.sin((F + i * 20) / 30) * 3}deg)` }}><I size={72} /></div>
              <div style={{ width: 170, fontFamily: FONT.display, fontWeight: 800, fontSize: 62, color: C.navy, lineHeight: 1 }}>{r.t}</div>
              <div style={{ flex: 1, height: 44, borderRadius: 22, background: '#EEF0F3', overflow: 'hidden' }}>
                <div style={{ width: `${grow * 100}%`, height: '100%', borderRadius: 22, background: `linear-gradient(90deg, ${r.col}cc, ${r.col})`, position: 'relative' }}>
                  <div style={{ position: 'absolute', top: 0, bottom: 0, width: 80, left: `${((F - at) * 3) % 140 - 20}%`, background: 'linear-gradient(90deg, transparent, rgba(255,255,255,.35), transparent)' }} />
                </div>
              </div>
              {struck && (
                <div style={{ position: 'absolute', left: 80, right: 0, top: 0, bottom: 0, display: 'flex', alignItems: 'center' }}>
                  <svg width={680} height={60} style={{ overflow: 'visible' }}><path d="M0 40 Q340 10 680 22" fill="none" stroke={C.ruby} strokeWidth={10} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - cp} /></svg>
                  <Cross size={66} p={cp} sw={13} style={{ position: 'absolute', right: -14 }} />
                </div>
              )}
            </div>
          );
        })}
      </Card>
    </div>
  );
};
