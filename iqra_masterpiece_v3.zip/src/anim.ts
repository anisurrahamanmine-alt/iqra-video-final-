import { Easing, interpolate, spring, SpringConfig } from 'remotion';
import { FPS } from './config';

export const SPR: Record<'pop' | 'snap' | 'soft' | 'slam', Partial<SpringConfig>> = {
  pop: { damping: 12, stiffness: 170, mass: 0.7 },
  snap: { damping: 15, stiffness: 240, mass: 0.6 },
  soft: { damping: 22, stiffness: 120, mass: 0.9 },
  slam: { damping: 10, stiffness: 260, mass: 0.8 },
};
export const easeOut = Easing.bezier(0.16, 1, 0.3, 1);
export const easeIO = Easing.bezier(0.65, 0, 0.35, 1);
const CL = { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' } as const;

/** spring progress 0..1 starting at absolute frame `at` */
export const sp = (F: number, at: number, k: keyof typeof SPR = 'pop') =>
  F < at ? 0 : spring({ frame: F - at, fps: FPS, config: SPR[k] });
/** clamped eased ramp */
export const ramp = (F: number, a: number, b: number, from = 0, to = 1, ease = easeOut) =>
  interpolate(F, [a, b], [from, to], { ...CL, easing: ease });
export const lin = (F: number, a: number, b: number, from = 0, to = 1) => interpolate(F, [a, b], [from, to], CL);
/** exit progress 0..1 (fast) */
export const out = (F: number, at: number, dur = 10) => ramp(F, at, at + dur, 0, 1, easeIO);
/** deterministic random */
export const rnd = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
/** standard card/text entrance: rises + fades + scales, then exits */
export const enterStyle = (F: number, at: number, opt: { k?: keyof typeof SPR; dy?: number; dx?: number; s0?: number; rot?: number; exitAt?: number; exitDur?: number; exitDy?: number; exitDx?: number } = {}) => {
  const { k = 'pop', dy = 60, dx = 0, s0 = 0.9, rot = 0, exitAt = 1e9, exitDur = 10, exitDy = -30, exitDx = 0 } = opt;
  const p = sp(F, at, k);
  const o = out(F, exitAt, exitDur);
  const op = Math.min(1, lin(F, at, at + 8)) * (1 - o);
  return {
    opacity: op,
    transform: `translate(${dx * (1 - p) + exitDx * o}px, ${dy * (1 - p) + exitDy * o}px) scale(${s0 + (1 - s0) * p - 0.04 * o}) rotate(${rot * (1 - p)}deg)`,
  } as React.CSSProperties;
};
/** gentle idle float */
export const idle = (F: number, seed = 0, amp = 4, period = 70) => Math.sin((F + seed * 37) / period * Math.PI * 2) * amp;
/** dim-for-focus factor: 1 normal, ~0.28 dimmed */
export const dimAt = (F: number, at: number, until = 1e9, to = 0.28) => {
  const d = ramp(F, at, at + 10) * (1 - ramp(F, until, until + 10));
  return { opacity: 1 - (1 - to) * d, filter: d > 0.01 ? `blur(${5 * d}px)` : undefined } as React.CSSProperties;
};
