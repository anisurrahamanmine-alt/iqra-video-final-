import React from 'react';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT } from '../theme';
import { Abs, Card } from '../components/Card';
import { BookClosed, IdBadge, Pause, ScrollSeal, Star8 } from '../components/Icons';
import { Key, KBlock, Pill, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';

const S = sc(5);
// cues: ইভেন 1070 · বলেননি 1111 · জীবন 1153 · ইসলাম 1192 · তোমরা 1214 · মুসলিম 1227 · এমনকি 1249 · স্বয়ং 1335 · নবী 1375 · কিংবা 1388 · কোরআনের 1441 · এসব 1463 · পরিচয় 1498 · আগে 1529
export const SFX05: SfxCue[] = [
  sx(1076, 'whoosh_a.mp3', 0.17), sx(1146, 'paper_slide.mp3', 0.2), sx(1153, 'pop_b.mp3', 0.16), sx(1206, 'key_click.mp3', 0.18, 12),
  sx(1214, 'pop_b.mp3', 0.16), sx(1244, 'key_click.mp3', 0.18, 12), sx(1262, 'pop_b.mp3', 0.16), sx(1335, 'shine.mp3', 0.1, 45),
  sx(1380, 'key_click.mp3', 0.18, 12), sx(1390, 'pop_b.mp3', 0.16), sx(1450, 'key_click.mp3', 0.18, 12), sx(1463, 'paper.mp3', 0.2),
  sx(1490, 'synth_riser_soft.wav', 0.14),
];

const PILLS = [
  { I: Star8, label: 'জীবনব্যবস্থার নাম', key: 'ইসলাম', at: 1153, lock: 1206, col: C.teal },
  { I: IdBadge, label: 'তোমাদের পরিচয়', key: 'মুসলিম', at: 1214, lock: 1244, col: C.navy },
  { I: ScrollSeal, label: 'নবুয়তের', key: 'ঘোষণা', at: 1262, lock: 1380, col: C.navy, glowAt: 1335 },
  { I: BookClosed, label: 'কোরআনের', key: 'পরিচয়', at: 1390, lock: 1450, col: C.teal },
];

export const Scene05: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="fromRight" exit="slideDown">
    {(F) => {
      const dim = ramp(F, 1463, 1478, 0, 1, easeIO);
      return (
        <>
          <Abs y={262}>
            <KBlock gap={0}>
              <Small F={F} at={1076} exitAt={1458} text="আল্লাহ তখন এটাও" size={62} />
              <Key F={F} at={1109} exitAt={1458} text="বলেননি" v="ruby" size={110} />
            </KBlock>
          </Abs>
          <Abs y={800} style={{ opacity: lin(F, 1146, 1154) * (1 - 0.75 * dim), filter: dim > 0.01 ? `blur(${5 * dim}px)` : undefined, transform: `translate(-50%, -50%) translateY(${110 * dim}px) scale(${1 - 0.05 * dim})` }}>
            <Card w={880} pad={34} style={{ display: 'flex', flexDirection: 'column', gap: 18, minHeight: 230 }}>
              {PILLS.map((p, i) => {
                const e = sp(F, p.at, 'pop');
                const lk = sp(F, p.lock, 'snap');
                const glow = p.glowAt ? ramp(F, p.glowAt, p.glowAt + 10) * (1 - ramp(F, p.lock, p.lock + 10)) : 0;
                const ul = p.glowAt ? ramp(F, p.glowAt + 4, p.glowAt + 22) : 0;
                return (
                  <div key={i} style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 24, height: 150 * Math.min(1, e * 1.15), marginTop: i ? 0 : 0, overflow: 'visible', padding: '0 28px', borderRadius: 999, background: lk > 0.5 ? '#F4F4F1' : '#FFFFFF', border: `2px solid ${lk > 0.5 ? C.hair : p.col + '55'}`, boxShadow: lk > 0.5 ? 'none' : '0 8px 20px rgba(20,30,48,.08)', opacity: lin(F, p.at, p.at + 6), transform: `translateX(${120 * (1 - e)}px) scale(${0.9 + 0.1 * e})` }}>
                    <div style={{ width: 108, height: 108, borderRadius: 30, background: `${p.col}12`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: glow > 0 ? `0 0 ${40 * glow}px ${C.gold}` : undefined, transform: `scale(${1 + 0.08 * glow * Math.sin(F / 4)})` }}><p.I size={76} /></div>
                    <div style={{ flex: 1, display: 'flex', alignItems: 'baseline', gap: 16, opacity: 1 - 0.45 * lk, whiteSpace: 'nowrap' }}>
                      <span style={{ fontFamily: FONT.sans, fontWeight: 600, fontSize: 46, color: C.ink }}>{p.label}</span>
                      <span style={{ position: 'relative', fontFamily: FONT.display, fontWeight: 800, fontSize: 72, color: C.navy, lineHeight: 1.1 }}>
                        {p.key}
                        {ul > 0 && <span style={{ position: 'absolute', left: 0, bottom: 2, height: 8, width: `${ul * 100}%`, borderRadius: 4, background: C.goldDeep }} />}
                      </span>
                    </div>
                    <div style={{ width: 84, display: 'flex', justifyContent: 'center', transform: `scale(${lk}) rotate(${(1 - lk) * -40}deg)`, opacity: lk }}>
                      <Pause size={72} />
                    </div>
                    {/* subtle "waiting" dots before lock */}
                    {F >= p.at + 8 && F < p.lock && (
                      <div style={{ position: 'absolute', right: 44, display: 'flex', gap: 8 }}>
                        {[0, 1, 2].map((d) => <div key={d} style={{ width: 12, height: 12, borderRadius: 6, background: C.goldDeep, opacity: 0.3 + 0.7 * Math.max(0, Math.sin((F - d * 5) / 5)) }} />)}
                      </div>
                    )}
                  </div>
                );
              })}
            </Card>
          </Abs>
          {/* before any identity was given */}
          <Abs y={700} style={{ transform: `translate(-50%, -50%) translateY(${idle(F, 2, 3, 60)}px)` }}>
            <Pill style={{ opacity: lin(F, 1463, 1470), padding: '22px 46px', borderRadius: 36 }}>
              <KBlock gap={0}>
                <Small F={F} at={1463} text="এসব কোনো ধরনের" size={62} />
                <Key F={F} at={1496} text="পরিচয় দেওয়ারও আগে" size={104} />
              </KBlock>
            </Pill>
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
