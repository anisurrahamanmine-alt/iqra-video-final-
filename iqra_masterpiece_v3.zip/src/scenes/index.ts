import { SFX01 } from './Scene01'; import { SFX02 } from './Scene02'; import { SFX03 } from './Scene03'; import { SFX04 } from './Scene04';
import { SFX05 } from './Scene05'; import { SFX06 } from './Scene06'; import { SFX07 } from './Scene07'; import { SFX08 } from './Scene08';
import { SFX09 } from './Scene09'; import { SFX10 } from './Scene10'; import { SFX11 } from './Scene11';
export * from './Scene01'; export * from './Scene02'; export * from './Scene03'; export * from './Scene04'; export * from './Scene05'; export * from './Scene06';
export * from './Scene07'; export * from './Scene08'; export * from './Scene09'; export * from './Scene10'; export * from './Scene11';
export const ALL_SFX = [...SFX01, ...SFX02, ...SFX03, ...SFX04, ...SFX05, ...SFX06, ...SFX07, ...SFX08, ...SFX09, ...SFX10, ...SFX11];
