import React from 'react';
import { idle, lin, out, ramp, rnd, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C } from '../theme';
import { Abs } from '../components/Card';
import { ExpectationChart } from '../components/ExpectationChart';
import { Crowd } from '../components/Crowd';
import { Question, Spark } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';

const S = sc(1);
// cues (abs frames): যদি 7 · ইসলামের 46 · গুরুত্বপূর্ণ 80 · বেশিরভাগ 141 · নামাজ 196 · রোজা 211 · যাকাত 232
export const SFX01: SfxCue[] = [
  // intro stays punchy (attention hook), then calmer
  sx(0, 'whoosh_a.mp3', 0.4), sx(0, 'pop_b.mp3', 0.32), sx(2, 'marker.mp3', 0.3), sx(38, 'whoosh_c.mp3', 0.26),
  sx(46, 'pop_c.mp3', 0.24), sx(81, 'marker.mp3', 0.24), sx(128, 'whoosh_d.mp3', 0.2), sx(152, 'paper_slide.mp3', 0.22),
  sx(194, 'synth_tick.wav', 0.28), sx(209, 'synth_tick.wav', 0.28), sx(230, 'synth_tick.wav', 0.28), sx(240, 'synth_chime_soft.wav', 0.1, 40),
];

const Streaks: React.FC<{ F: number; at: number; until: number }> = ({ F, at, until }) => {
  const o = lin(F, at, at + 3) * (1 - out(F, until, 8));
  return (
    <svg width={1080} height={420} style={{ position: 'absolute', left: 0, top: 500, opacity: o }}>
      {Array.from({ length: 7 }).map((_, i) => {
        const x = ramp(F, at + i, at + 16 + i, -500, 1400);
        return <line key={i} x1={x} y1={40 + i * 52} x2={x + 220 + rnd(i) * 160} y2={40 + i * 52} stroke={i % 2 ? C.teal : C.goldDeep} strokeOpacity={0.35} strokeWidth={5} strokeLinecap="round" />;
      })}
    </svg>
  );
};

const Sparks: React.FC<{ F: number; at: number; until: number; y: number }> = ({ F, at, until, y }) => (
  <>
    {[[-380, -90], [390, -120], [-340, 120], [360, 100]].map(([dx, dy], i) => {
      const p = sp(F, at + 4 + i * 2, 'pop');
      return <div key={i} style={{ position: 'absolute', left: 540 + dx - 18, top: y + dy - 18, opacity: p * (1 - out(F, until, 8)), transform: `scale(${p}) rotate(${F * 2 + i * 30}deg)` }}><Spark size={36} /></div>;
    })}
  </>
);

export const Scene01: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="none" exit="none">
    {(F) => (
      <>
        {/* Beat A: frame-0 sticker hook */}
        <Streaks F={F} at={-4} until={36} />
        <Sparks F={F} at={-6} until={36} y={700} />
        <Abs y={700}>
          <KBlock gap={6}>
            <Small F={F} at={-4} exitAt={38} text="যদি কাউকে" size={70} stagger={2} />
            <Key F={F} at={-3} exitAt={38} text="প্রশ্ন করা হয়" k="slam" size={132} tilt={-3} />
          </KBlock>
        </Abs>
        <div style={{ position: 'absolute', left: 820, top: 520, opacity: lin(F, -2, 4) * (1 - out(F, 38, 8)), transform: `translateY(${idle(F, 1, 10, 18)}px) rotate(${12 + idle(F, 2, 6, 24)}deg) scale(${sp(F, -2, "pop")})` }}>
          <Question size={120} />
        </div>
        {/* Beat B: the question */}
        <Abs y={720}>
          <KBlock gap={8}>
            <Small F={F} at={46} exitAt={132} text="ইসলামের সবচেয়ে" size={72} />
            <Key F={F} at={78} exitAt={132} text="গুরুত্বপূর্ণ কাজ কী?" size={124} k="pop" tilt={2} />
          </KBlock>
        </Abs>
        <Sparks F={F} at={78} until={130} y={760} />
        <div style={{ position: 'absolute', left: 860, top: 560, opacity: lin(F, 100, 106) * (1 - out(F, 130, 8)), transform: `translateY(${idle(F, 3, 9, 16)}px) rotate(${-10 + idle(F, 4, 8, 22)}deg) scale(${sp(F, 100, 'pop')})` }}>
          <Question size={96} c={C.teal} />
        </div>
        {/* Beat C: most people would say -> expectation chart */}
        <Abs y={262}>
          <KBlock gap={0}>
            <Small F={F} at={141} text="বেশিরভাগ মানুষই" size={64} exitAt={244} />
            <Key F={F} at={180} text="বলবে —" size={100} v="teal" exitAt={244} />
          </KBlock>
        </Abs>
        <Abs y={488}>
          <Crowd F={F} at={143} exitAt={244} bubbleAts={[194, 209, 230]} />
        </Abs>
        <Abs y={880}>
          <ExpectationChart F={F} enterAt={150} barAts={[196, 211, 232]} />
        </Abs>
      </>
    )}
  </SceneShell>
);
