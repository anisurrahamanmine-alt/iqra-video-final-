import React from 'react';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT, SHADOW } from '../theme';
import { Abs } from '../components/Card';
import { Question, Spark } from '../components/Icons';
import { Person } from '../components/Characters';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { Tier } from '../components/Tier';
import { Slash } from '../components/Icons';

const S = sc(7);
// cues: এবার 1838 · জাস্ট 1871 · ভাবেন 1882 · স্বয়ং 1900 · প্রথম 1960 · সাধারণ 2013 · গুরুত্বহীন 2032 · আছে? 2076 · এর 2099 · গভীর 2125 · তাৎপর্যই 2132 · লুকিয়ে 2154 · তাই না 2181
export const SFX07: SfxCue[] = [
  sx(1832, 'page_flip.mp3', 0.18), sx(1897, 'pop_a.mp3', 0.13), sx(2013, 'pop_b.mp3', 0.18), sx(2072, 'synth_slash.wav', 0.26),
  sx(2084, 'whoosh_b.mp3', 0.16), sx(2104, 'pop_a.mp3', 0.12), sx(2125, 'synth_tick.wav', 0.24), sx(2140, 'synth_tick.wav', 0.24),
  sx(2154, 'synth_tick.wav', 0.24), sx(2186, 'whoosh_c.mp3', 0.18),
];

// final জ্ঞান band position (= Scene 8 pyramid base)
export const BASE = { y: 1090, w: 820, h: 150, top: 0.86 };

export const Scene07: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="unfold" exit="none">
    {(F) => {
      const tagP = sp(F, 2013, 'pop');
      const tagOut = ramp(F, 2084, 2096, 0, 1, easeIO);
      const morph = ramp(F, 2186, 2200, 0, 1, easeIO);
      const rest = 1 - morph;
      const L = (at: number) => sp(F, at, 'pop');
      const pulse = ramp(F, 2181, 2186) * (1 - ramp(F, 2186, 2196));
      const lineDraw = (a: number) => ramp(F, a, a + 12);
      return (
        <>
          <Abs y={720}>
            <KBlock gap={0}>
              <Small F={F} at={1838} exitAt={1894} text="এবার আপনি" size={68} />
              <Key F={F} at={1869} exitAt={1894} text="জাস্ট ভাবেন" size={128} />
            </KBlock>
            <div style={{ position: 'absolute', right: -70, top: -30, transform: `scale(${sp(F, 1874, 'pop')}) rotate(${F * 2}deg)`, opacity: 1 - lin(F, 1894, 1902) }}><Spark size={56} /></div>
          </Abs>
          <Abs y={320}>
            <KBlock gap={0}>
              <Small F={F} at={1900} exitAt={2090} text="স্বয়ং আল্লাহর পক্ষ থেকে আসা" size={60} />
              <Key F={F} at={1958} exitAt={2090} text="এই প্রথম নির্দেশ" size={112} />
            </KBlock>
          </Abs>
          {/* thinker (from "জাস্ট ভাবেন" until "সাধারণ / গুরুত্বহীন" is struck away) */}
          {(() => {
            const tp = sp(F, 1896, 'soft');
            const raise = sp(F, 1906, 'soft');
            const ex = ramp(F, 2086, 2100, 0, 1, easeIO);
            const shake = F >= 2072 && F < 2092 ? Math.sin((F - 2072) / 1.6) * (1 - (F - 2072) / 20) : 0;
            const look = F >= 2013 ? ramp(F, 2013, 2024) : 0;
            const wonder = Math.sin((F - 1906) / 24);
            const bub = sp(F, 1918, 'pop');
            return (
              <Abs y={735} style={{ opacity: lin(F, 1896, 1904) * (1 - ex), transform: `translate(-50%, -50%) translateY(${180 * (1 - tp) + 60 * ex}px)` }}>
                <div style={{ position: 'relative', width: 420, display: 'flex', justifyContent: 'center' }}>
                  <Person w={300} shirt="#3F5C8A" pose={{ tilt: -5 + 4 * raise + 3 * wonder * (1 - look) + 8 * look, turn: 0.7 * wonder * (1 - look) - 0.6 * look + 1.3 * shake, aR1: -12 + 91 * raise, aR2: 6 + 131 * raise, aL1: 14 - 50 * raise, aL2: -4 - 70 * raise, bob: idle(F, 3, 3, 55) }} />
                  {[0, 1, 2].map((i) => {
                    const p = sp(F, 1912 + i * 5, 'pop');
                    return <div key={i} style={{ position: 'absolute', left: 300 + i * 26, top: 70 - i * 34, width: 16 + i * 10, height: 16 + i * 10, borderRadius: '50%', background: C.card, border: `3px solid ${C.goldDeep}`, transform: `scale(${p})`, opacity: p }} />;
                  })}
                  <div style={{ position: 'absolute', left: 330, top: -60, width: 120, height: 104, borderRadius: 52, background: C.card, border: `3px solid ${C.goldDeep}`, boxShadow: SHADOW.soft, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: bub, transform: `scale(${bub * (1 + 0.05 * Math.sin(F / 7))}) translateY(${idle(F, 5, 4, 40)}px)` }}>
                    {F < 2076 ? <Question size={64} c={C.teal} sw={10} /> : <Spark size={56} />}
                  </div>
                </div>
              </Abs>
            );
          })()}
          {/* "ordinary / unimportant?" — struck & swept */}
          <Abs y={1130} style={{ opacity: lin(F, 2013, 2019) * (1 - tagOut), transform: `translate(-50%, -50%) translate(${-900 * tagOut}px, ${40 * (1 - tagP) + idle(F, 3, 3, 40)}px) scale(${0.7 + 0.3 * tagP})` }}>
            <div style={{ position: 'relative', padding: '18px 50px', borderRadius: 999, background: C.rubySoft, border: `2px solid ${C.ruby}55`, boxShadow: SHADOW.soft, whiteSpace: 'nowrap' }}>
              <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 84, color: C.ruby }}>সাধারণ / গুরুত্বহীন?</span>
              <div style={{ position: 'absolute', left: 24, right: 24, top: '36%' }}><Slash w={660} h={44} p={ramp(F, 2072, 2081)} sw={12} c={C.navy} /></div>
            </div>
          </Abs>
          {/* Depth / layers diagram */}
          <div style={{ position: 'absolute', inset: 0, opacity: rest }}>
            <Abs y={300}>
              <KBlock gap={0}>
                <Small F={F} at={2099} text="এর মাঝে লুকিয়ে আছে" size={62} />
                <Key F={F} at={2123} text="গভীর তাৎপর্য!" v="teal" size={118} />
              </KBlock>
            </Abs>
            {/* surface line */}
            <svg width={1080} height={60} style={{ position: 'absolute', left: 0, top: 600, opacity: lin(F, 2108, 2118) }}>
              <path d={`M80 30 ${Array.from({ length: 12 }).map((_, i) => `Q ${120 + i * 80} ${30 + (i % 2 ? 14 : -14) * Math.sin((F + i * 9) / 14)} ${160 + i * 80} 30`).join(' ')}`} fill="none" stroke={C.teal} strokeOpacity={0.45} strokeWidth={3} strokeDasharray="10 8" />
            </svg>
            <Abs y={545} style={{ opacity: lin(F, 2103, 2110), transform: `translate(-50%, -50%) scale(${0.7 + 0.3 * L(2103)}) translateY(${idle(F, 1, 3, 50)}px)` }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, padding: '14px 40px', borderRadius: 999, background: C.card, border: `2px solid ${C.goldDeep}66`, boxShadow: SHADOW.card, whiteSpace: 'nowrap' }}>
                <span style={{ fontFamily: FONT.sans, fontWeight: 600, fontSize: 46, color: C.ink }}>একটি শব্দ:</span>
                <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 68, color: C.teal }}>ইকরা</span>
              </div>
            </Abs>
            {/* glowing connectors */}
            <svg width={1080} height={1920} style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
              {[[630, 700, 2120], [790, 850, 2136], [940, 1010, 2150]].map(([a, b, at], i) => (
                <g key={i}>
                  <line x1={540} y1={a} x2={540} y2={b} stroke={C.gold} strokeWidth={14} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - lineDraw(at)} opacity={0.6} />
                  <line x1={540} y1={a} x2={540} y2={b} stroke={C.goldDeep} strokeWidth={4} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - lineDraw(at)} />
                </g>
              ))}
            </svg>
            <Tier y={770} w={560} h={120} top={0.88} fill="#E0E7FF" color={C.navy} size={58} text="চিন্তা" glow={pulse} style={{ opacity: lin(F, 2125, 2131), transform: `translateY(${-40 * (1 - L(2125))}px) scale(${0.8 + 0.2 * L(2125)})` }} />
            <Tier y={925} w={700} h={130} top={0.88} fill={C.champagne} color={C.navy} size={60} text="সভ্যতা" glow={pulse} style={{ opacity: lin(F, 2140, 2146), transform: `translateY(${-40 * (1 - L(2140))}px) scale(${0.8 + 0.2 * L(2140)})` }} />
          </div>
          {/* deepest layer: জ্ঞান (morphs into Scene 8 pyramid base) */}
          <Tier y={1075 + (BASE.y - 1075) * morph} w={820} h={140 + 10 * morph} top={BASE.top} fill={C.teal} size={66} text="জ্ঞান" glow={0.6 * (0.6 + 0.4 * Math.sin(F / 9)) * lin(F, 2154, 2170) + pulse}
            style={{ opacity: lin(F, 2154, 2160), transform: `translateY(${-40 * (1 - L(2154))}px) scale(${0.8 + 0.2 * L(2154)})` }} />
        </>
      );
    }}
  </SceneShell>
);
