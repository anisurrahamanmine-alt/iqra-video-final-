import React from 'react';
import { idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT } from '../theme';
import { Abs, Card } from '../components/Card';
import { CharityHand, Crescent, Mosque, Pause, Shield } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { Person } from '../components/Characters';
import { HeaderAnchor } from '../components/HeaderAnchor';

const S = sc(4);
// cues: লিটারেলি 775 · একটু 790 · বিষয়টা 822 · মানে 844 · প্রথমেই 898 · নামাজ 943 · রোজা 965 · যাকাত 988 · গুনাহ 1020 · তাই না 1051
export const SFX04: SfxCue[] = [
  sx(764, 'whoosh_d.mp3', 0.18), sx(775, 'pop_c.mp3', 0.18), sx(834, 'whoosh_c.mp3', 0.16), sx(941, 'pop_b.mp3', 0.18),
  sx(962, 'pop_a.mp3', 0.16), sx(986, 'pop_b.mp3', 0.18), sx(1010, 'pop_a.mp3', 0.16), sx(1049, 'ding.mp3', 0.13, 40),
  sx(1055, 'key_click.mp3', 0.18, 10), sx(1062, 'key_click.mp3', 0.18, 10),
];

const CARDS = [
  { t: ['নামাজ পড়ো'], I: Mosque, at: 941, c: C.navy, pz: 1054 },
  { t: ['রোজা রাখো'], I: Crescent, at: 962, c: C.teal, pz: 1057 },
  { t: ['যাকাত দাও'], I: CharityHand, at: 986, c: C.goldDeep, pz: 1060 },
  { t: ['গুনাহ থেকে', 'দূরে থাকো'], I: Shield, at: 1010, c: C.navy, pz: 1063 },
];

export const Scene04: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="none" exit="toLeft">
    {(F) => {
      const tp = sp(F, 775, 'soft');
      const raise = sp(F, 790, 'soft');
      const think = Math.sin((F - 790) / 22);
      const th = ramp(F, 834, 846);
      const titleShrink = ramp(F, 930, 946);
      return (
        <>
          <HeaderAnchor F={F} at={770} outAt={836} />
          {/* thinker with hand-on-chin micro-acting */}
          <Abs y={650} style={{ opacity: lin(F, 775, 783) * (1 - th), transform: `translate(-50%, -50%) translateY(${200 * (1 - tp) - 40 * th}px)` }}>
            <div style={{ position: 'relative' }}>
              <Person w={330} shirt={C.teal} pose={{ tilt: -4 + 5 * raise + 2 * think, turn: 0.6 * raise, aR1: -12 + 91 * raise, aR2: 6 + 131 * raise, aL1: 14 - 50 * raise, aL2: -4 - 70 * raise, bob: idle(F, 1, 3, 60) }} />
              {[0, 1, 2].map((i) => {
                const p = sp(F, 800 + i * 6, 'pop');
                return <div key={i} style={{ position: 'absolute', left: 250 + i * 42, top: 60 - i * 46, width: 22 + i * 14, height: 22 + i * 14, borderRadius: '50%', background: C.card, border: `3px solid ${C.goldDeep}`, transform: `scale(${p})`, opacity: p }} />;
              })}
            </div>
          </Abs>
          <Abs y={1110}>
            <KBlock gap={0}>
              <Small F={F} at={790} exitAt={836} text="একটু ভাবতে পারছেন" size={66} />
              <Key F={F} at={820} exitAt={836} text="বিষয়টা?" size={128} tilt={-2} />
            </KBlock>
          </Abs>
          {/* what could have been first */}
          <Abs y={355 - 40 * titleShrink} style={{ transform: `translate(-50%, -50%) scale(${1 - 0.18 * titleShrink})` }}>
            <KBlock gap={0}>
              <Small F={F} at={846} text="মানে, আল্লাহ তো চাইলে" size={60} />
              <Key F={F} at={898} text="প্রথমেই বলতে পারতেন" size={100} />
            </KBlock>
          </Abs>
          <Abs y={820}>
            <div style={{ display: 'grid', gridTemplateColumns: '420px 420px', gap: 24, transform: `scale(${1 + 0.02 * Math.sin((F - 940) / 40)})` }}>
              {CARDS.map((c, i) => {
                const p = sp(F, c.at, 'pop');
                const pz = sp(F, c.pz, 'snap');
                return (
                  <div key={i} style={{ opacity: lin(F, c.at, c.at + 6), transform: `translateY(${50 * (1 - p) + idle(F, i, 3, 55)}px) scale(${0.6 + 0.4 * p})` }}>
                    <Card w={420} h={252} pad={24} tone={pz > 0.5 ? '#F6F5F1' : C.card} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                      <div style={{ position: 'absolute', right: 18, top: 18, opacity: pz, transform: `scale(${pz}) rotate(${(1 - pz) * -60}deg)`, zIndex: 2 }}><Pause size={58} /></div>
                      <div style={{ position: 'absolute', inset: 0, borderRadius: 20, border: `3px solid ${C.goldDeep}`, opacity: 0.7 * pz }} />
                      <div style={{ opacity: 1 - 0.4 * pz, width: 96, height: 96, borderRadius: 24, background: `${c.c}14`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><c.I size={68} /></div>
                      <div style={{ opacity: 1 - 0.4 * pz, fontFamily: FONT.display, fontWeight: 800, fontSize: c.t.length > 1 ? 50 : 60, lineHeight: 1.05, color: C.navy, textAlign: 'center' }}>{c.t.map((l, j) => <div key={j}>{l}</div>)}</div>
                    </Card>
                  </div>
                );
              })}
            </div>
          </Abs>
          <Abs y={1185}>
            <Key F={F} at={1049} text="তাই না?" v="teal" size={96} tilt={-4} />
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
