import React from 'react';
import { idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT, SHADOW } from '../theme';
import { Abs, Card } from '../components/Card';
import { Spark } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { Tier } from '../components/Tier';
import { BASE } from './Scene07';

const S = sc(8);
// cues: পড়া 2207 · জ্ঞান 2221 · ইসলামে 2241 · কতটা 2253 · ইম্পর্টেন্ট 2266 · সেটা 2304 · এই 2339 · প্রথম 2344 · সহজেই 2376 · পারি 2396
export const SFX08: SfxCue[] = [
  sx(2207, 'thud_heavy.mp3', 0.15, 40), sx(2243, 'pop_a.mp3', 0.18), sx(2266, 'pop_b.mp3', 0.18), sx(2290, 'ding.mp3', 0.12, 45),
  sx(2340, 'pop_a.mp3', 0.16), sx(2345, 'shine.mp3', 0.11, 50),
];

export const Scene08: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="none" exit="toLeft">
    {(F) => {
      const slam = sp(F, 2207, 'slam');
      const bump = 1 + 0.06 * Math.sin(Math.min(1, (F - 2207) / 12) * Math.PI) * (F >= 2207 ? 1 : 0);
      const lab = lin(F, 2204, 2212);
      const m = sp(F, 2243, 'pop');
      const t = sp(F, 2266, 'pop');
      const glow = ramp(F, 2339, 2350) * (0.6 + 0.4 * Math.sin(F / 7));
      return (
        <>
          <Abs y={865} style={{ opacity: lin(F, 2204, 2216), transform: `translate(-50%, -50%) scale(${0.96 + 0.04 * lin(F, 2204, 2216)})` }}>
            <Card w={880} h={650} marks />
          </Abs>
          <Abs y={330}>
            <KBlock gap={0}>
              <Small F={F} at={2210} exitAt={2330} text="ইসলামে জ্ঞান অর্জন" size={64} />
              <Key F={F} at={2251} exitAt={2330} text="কতটা ইম্পর্টেন্ট!" size={112} />
            </KBlock>
          </Abs>
          <Abs y={330}>
            <KBlock gap={0}>
              <Small F={F} at={2338} text="এই প্রথম নির্দেশ থেকে" size={62} />
              <Key F={F} at={2374} text="সহজেই বুঝতে পারি" v="teal" size={108} />
            </KBlock>
          </Abs>
          {/* "the first command" = اقْرَأْ · পড়ো (appears on "আল্লাহর এই প্রথম নির্দেশ থেকে") */}
          {(() => {
            const cp = sp(F, 2340, 'pop');
            const gl = 0.6 + 0.4 * Math.sin(F / 8);
            return (
              <Abs y={640} style={{ opacity: lin(F, 2340, 2346), transform: `translate(-50%, -50%) translateY(${-40 * (1 - cp) + idle(F, 6, 3, 45)}px) scale(${0.6 + 0.4 * cp})` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 22, padding: '6px 34px', borderRadius: 999, background: 'linear-gradient(90deg, #FFFBEB, #ECFDF8)', border: `3px solid ${C.goldDeep}`, boxShadow: `${SHADOW.card}, 0 0 ${36 * gl}px ${C.gold}` }}>
                  <span dir="rtl" lang="ar" style={{ unicodeBidi: 'embed', fontFamily: "'Amiri V', serif", fontWeight: 700, fontSize: 70, lineHeight: 1.55, color: C.teal }}>اقْرَأْ</span>
                  <svg width={46} height={24} viewBox="0 0 46 24"><path d="M2 12 H38 M30 4 L40 12 L30 20" stroke={C.goldDeep} strokeWidth={4} fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
                  <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 64, color: C.navy, background: C.gold, borderRadius: 14, padding: '0 16px', lineHeight: 1.2 }}>পড়ো</span>
                </div>
              </Abs>
            );
          })()}
          {/* 3-tier foundation pyramid, built bottom-up */}
          <Tier y={BASE.y} w={BASE.w} h={BASE.h} top={BASE.top} fill={C.teal} glow={glow} size={54}
            text={<span style={{ position: 'relative' }}><span style={{ opacity: 1 - lab, position: 'absolute', left: '50%', transform: 'translateX(-50%)', fontSize: 66 }}>জ্ঞান</span><span style={{ opacity: lab }}>পড়া ও জ্ঞান অর্জন (ইকরা)</span></span>}
            style={{ transform: `scale(${bump}) translateY(${-8 * (1 - slam)}px)` }} />
          <Tier y={BASE.y - 150} w={620} h={140} top={0.8} fill={C.navy} size={54} text="সঠিক বুঝ ও ইমান"
            style={{ opacity: lin(F, 2243, 2249), transform: `translateY(${-90 * (1 - m)}px) scale(${0.85 + 0.15 * m})` }} />
          <Tier y={BASE.y - 295} w={520} h={140} top={0.7} fill={C.navy} border={C.goldDeep} size={40} text="সঠিক আমল ও ইবাদত"
            style={{ opacity: lin(F, 2266, 2272), transform: `translateY(${-90 * (1 - t) + idle(F, 2, 2, 50)}px) scale(${0.85 + 0.15 * t})` }} />
          {[[150, 1160], [930, 1040], [880, 760]].map(([x, y], i) => (
            <div key={i} style={{ position: 'absolute', left: x, top: y, opacity: ramp(F, 2288 + i * 3, 2296 + i * 3) * (0.6 + 0.4 * Math.sin(F / 6 + i)), transform: `scale(${sp(F, 2288 + i * 3, 'pop')}) rotate(${F * 2}deg)` }}><Spark size={40} /></div>
          ))}
        </>
      );
    }}
  </SceneShell>
);
