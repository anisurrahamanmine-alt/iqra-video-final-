import React from 'react';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT, SHADOW } from '../theme';
import { Abs, Card } from '../components/Card';
import { BookOpen, Check, Cross } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { Person } from '../components/Characters';

const S = sc(9);
// cues: না বুঝে 2423 · অন্ধভাবে 2437 · ধর্ম 2499 · নয় 2508 · যে 2532 · পড়ো 2570 · দিয়ে 2593 · সেই 2608 · অজ্ঞতার 2627 · জায়গা 2654 · না 2694
export const SFX09: SfxCue[] = [
  sx(2414, 'whoosh_a.mp3', 0.18), sx(2424, 'paper_slide.mp3', 0.13), sx(2508, 'thud_ground.mp3', 0.15, 30), sx(2533, 'pop_c.mp3', 0.16),
  sx(2572, 'synth_chime_soft.wav', 0.1, 45), sx(2627, 'pop_b.mp3', 0.18), sx(2654, 'whoosh_b.mp3', 0.22), sx(2686, 'whoosh_cine.mp3', 0.2, 40),
];

export const Scene09: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="fromRight" exit="none">
    {(F) => {
      const lp = sp(F, 2423, 'pop');
      const rp = sp(F, 2532, 'pop');
      const stamp = sp(F, 2508, 'slam');
      const chk = ramp(F, 2572, 2584);
      const fly = ramp(F, 2684, 2712, 0, 1, easeIO);
      const fadeRest = 1 - ramp(F, 2680, 2696);
      const grope = Math.sin((F - 2423) / 14);
      const tag = sp(F, 2627, 'pop');
      const tagOut = ramp(F, 2654, 2666, 0, 1, easeIO);
      return (
        <>
          <div style={{ position: 'absolute', inset: 0, opacity: fadeRest }}>
            <Abs y={720}>
              <Card w={880} h={660} pad={0} style={{ display: 'flex', overflow: 'hidden' }}>
                {/* left: blind acceptance */}
                <div style={{ position: 'relative', width: 439, height: '100%', background: '#FFF4F5', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', opacity: lin(F, 2423, 2430), transform: `translateY(${60 * (1 - lp)}px)` }}>
                  <div style={{ transform: `translateX(${grope * 8}px)` }}>
                    <Person w={250} shirt="#64748B" blindfold={1} pose={{ turn: grope * 0.8, tilt: grope * 4, aL1: 36 + grope * 8, aL2: -40, aR1: -36 + grope * 8, aR2: 40, bob: idle(F, 2, 3, 30) }} />
                  </div>
                  <div style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 58, color: C.ruby, marginTop: 6 }}>অন্ধভাবে মানা</div>
                  {/* stamp */}
                  <div style={{ position: 'absolute', top: 150, left: 0, right: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: lin(F, 2508, 2511), transform: `scale(${2 - stamp}) rotate(-8deg)` }}>
                    <Cross size={190} p={ramp(F, 2508, 2516)} sw={12} />
                    <div style={{ marginTop: -8, padding: '6px 30px', border: `6px solid ${C.ruby}`, borderRadius: 14, background: '#FFFFFFE6', fontFamily: FONT.display, fontWeight: 800, fontSize: 64, color: C.ruby }}>ধর্ম নয়</div>
                  </div>
                </div>
                <div style={{ width: 2, background: C.hair }} />
                {/* right: read & know */}
                <div style={{ position: 'relative', width: 439, height: '100%', background: `rgba(13,148,136,${0.05 + 0.07 * rp})`, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, opacity: lin(F, 2532, 2540) }}>
                  <div style={{ opacity: 1 - fly, transform: `scale(${0.6 + 0.4 * rp}) translateY(${idle(F, 1, 5, 45)}px)` }}><BookOpen size={280} glow={0.7 + 0.3 * Math.sin(F / 10)} /></div>
                  <div style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 58, color: C.teal, transform: `translateY(${30 * (1 - rp)}px)` }}>পড়ো ও জানো</div>
                  <div style={{ position: 'absolute', top: 40, right: 40, width: 96, height: 96, borderRadius: 48, background: '#FFFFFF', boxShadow: SHADOW.soft, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${sp(F, 2572, 'pop')})` }}><Check size={64} p={chk} /></div>
                </div>
              </Card>
            </Abs>
            <Abs y={1135}><Small F={F} at={2608} text="সেই ইসলামে" size={62} /></Abs>
            {/* ignorance tag, swiped off */}
            <Abs y={1245} style={{ opacity: lin(F, 2627, 2632) * (1 - tagOut), transform: `translate(-50%, -50%) translateX(${1000 * tagOut}px) scale(${0.6 + 0.4 * tag}) rotate(${-4 + 4 * tag}deg)` }}>
              <div style={{ padding: '10px 44px', borderRadius: 999, background: C.rubySoft, border: `2px solid ${C.ruby}66`, fontFamily: FONT.display, fontWeight: 800, fontSize: 84, color: C.ruby, boxShadow: SHADOW.soft }}>অজ্ঞতা</div>
            </Abs>
            <Abs y={1250}><KBlock><Key F={F} at={2660} text="অজ্ঞতার জায়গা নেই!" v="ruby" k="slam" size={100} /></KBlock></Abs>
          </div>
          {/* hand-off: the glowing book flies to centre (into Scene 10's learner) */}
          {fly > 0 && (
            <div style={{ position: 'absolute', left: 760 + (540 - 760) * fly - 140, top: 640 + (600 - 640) * fly - 100, transform: `scale(${1 + 1.4 * fly})`, opacity: 1 - ramp(F, 2706, 2716) }}>
              <BookOpen size={280} glow={1} />
            </div>
          )}
        </>
      );
    }}
  </SceneShell>
);
