import React from 'react';
import { easeIO, idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C } from '../theme';
import { Abs } from '../components/Card';
import { ExpectationChart } from '../components/ExpectationChart';
import { Question } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { TopLight, Vignette } from '../components/Atmos';

const S = sc(2);
// cues: কিন্তু 256 · অবাক 283 · আল্লাহর 305 · একদম 353 · এর 390 · কোনোটাই 404 · ছিল 418 · না 425 · তাহলে 446 · সেই 464 · নির্দেশ? 476
export const SFX02: SfxCue[] = [
  sx(254, 'whoosh_b.mp3', 0.24), sx(286, 'marker.mp3', 0.13), sx(388, 'synth_slash.wav', 0.24), sx(398, 'synth_slash.wav', 0.24),
  sx(408, 'synth_slash.wav', 0.24), sx(427, 'boom_cine.mp3', 0.22, 40), sx(446, 'synth_riser_soft.wav', 0.14), sx(486, 'whoosh_cine.mp3', 0.22, 45),
];

/** mystery parchment seal with pulsing gold question mark */
const MysterySeal: React.FC<{ F: number; at: number }> = ({ F, at }) => {
  const p = sp(F, at, 'soft');
  const pulse = 1 + 0.05 * Math.sin((F - at) / 6);
  return (
    <div style={{ opacity: lin(F, at, at + 8), transform: `translateY(${140 * (1 - p) + idle(F, 0, 4, 60)}px) scale(${0.8 + 0.2 * p})` }}>
      <svg width={360} height={360} viewBox="0 0 200 200" style={{ overflow: 'visible' }}>
        <defs><radialGradient id="sealg" cx="0.5" cy="0.4" r="0.6"><stop offset="0" stopColor="#FFFBEB" /><stop offset="1" stopColor="#F7E7BF" /></radialGradient></defs>
        <circle cx={100} cy={100} r={98} fill={C.gold} opacity={0.25 + 0.1 * Math.sin(F / 8)} />
        <path d={Array.from({ length: 24 }).map((_, i) => { const a = (i / 24) * Math.PI * 2; const r = i % 2 ? 84 : 92; return `${i ? 'L' : 'M'}${100 + r * Math.cos(a)} ${100 + r * Math.sin(a)}`; }).join(' ') + 'Z'} fill="url(#sealg)" stroke={C.goldDeep} strokeWidth={2.5} />
        <circle cx={100} cy={100} r={66} fill="none" stroke={C.goldDeep} strokeOpacity={0.55} strokeWidth={1.6} strokeDasharray="3 5" transform={`rotate(${F * 0.4} 100 100)`} />
        <g transform={`translate(100 100) scale(${pulse}) translate(-36 -40)`}><Question size={72} sw={11} /></g>
      </svg>
    </div>
  );
};

export const Scene02: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="none" exit="zoomThrough" origin="540px 640px">
    {(F) => {
      const atmos = ramp(F, 256, 290);
      const chartOut = ramp(F, 417, 432, 0, 1, easeIO);
      return (
        <>
          <Vignette o={atmos * 0.9} />
          <TopLight o={atmos * 0.55} floorY={1220} />
          {/* first text beat */}
          <Abs y={372}>
            <KBlock gap={0}>
              <Small F={F} at={256} exitAt={300} text="কিন্তু জানলে" size={64} />
              <Key F={F} at={283} exitAt={300} text="অবাক হবেন" size={108} />
            </KBlock>
          </Abs>
          <Abs y={372}>
            <KBlock gap={0}>
              <Small F={F} at={305} exitAt={386} text="আল্লাহর পক্ষ থেকে আসা" size={60} />
              <Key F={F} at={352} exitAt={386} text="একদম প্রথম নির্দেশ" size={100} />
            </KBlock>
          </Abs>
          {/* the same chart from Scene 1, now struck through */}
          <Abs y={880} style={{ opacity: 1 - chartOut, transform: `translate(-50%, -50%) translate(${-260 * chartOut}px, ${360 * chartOut}px) scale(${1 - 0.25 * chartOut}) rotate(${-6 * chartOut}deg)` }}>
            <ExpectationChart F={F} enterAt={-200} barAts={[-200, -200, -200]} crossAts={[388, 398, 408]} />
          </Abs>
          {/* slam: none of these */}
          <Abs y={720}>
            <KBlock gap={4}>
              <Small F={F} at={420} exitAt={442} text="এর কোনোটাই" size={72} />
              <Key F={F} at={427} exitAt={442} text="ছিল না!" v="ruby" k="slam" size={190} />
            </KBlock>
          </Abs>
          {/* suspense question */}
          <Abs y={600}><MysterySeal F={F} at={446} /></Abs>
          <Abs y={1000}>
            <KBlock gap={0}>
              <Small F={F} at={448} text="তাহলে কী ছিল" size={66} />
              <Key F={F} at={464} text="সেই প্রথম নির্দেশ?" size={108} />
            </KBlock>
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
