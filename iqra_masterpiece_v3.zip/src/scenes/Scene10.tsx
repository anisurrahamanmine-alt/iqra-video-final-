import React from 'react';
import { idle, lin, ramp, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C } from '../theme';
import { Abs, Card } from '../components/Card';
import { BookOpen, Compass } from '../components/Icons';
import { Key, KBlock, Small } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';
import { Person } from '../components/Characters';

const S = sc(10);
// cues: একজন 2708 · প্রকৃত 2718 · মুসলিমের 2732 · আসল 2749 · মিশনই 2757 · সবার 2781 · আগে 2791 · জ্ঞান 2799 · অর্জন 2811 · করা 2823
export const SFX10: SfxCue[] = [
  sx(2712, 'book_open.mp3', 0.28), sx(2750, 'marker.mp3', 0.15), sx(2754, 'synth_tick.wav', 0.26), sx(2782, 'bell.mp3', 0.1, 50),
  sx(2812, 'synth_swell.wav', 0.14),
];

export const Scene10: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="zoomIn" exit="fade">
    {(F) => {
      const open = ramp(F, 2712, 2728);
      const lift = sp(F, 2730, 'soft');
      const rot = F < 2752 ? (F - 2704) * 9 + 30 * Math.sin((F - 2704) / 6) : 0;
      const lock = ramp(F, 2752, 2770);
      const cp = sp(F, 2708, 'pop');
      const ulGrow = ramp(F, 2830, 2852);
      return (
        <>
          <Abs y={520}>
            <Card w={880} h={640} pad={0} style={{ overflow: 'hidden', background: 'linear-gradient(180deg, #FFFEFA, #F3FBF8)' }}>
              <div style={{ position: 'absolute', left: 290, top: 196, transform: `translateY(${idle(F, 0, 3, 60)}px)` }}>
                <Person w={300} variant="hijab" shirt={C.teal} eyesUp={lift > 0.5}
                  pose={{ tilt: -3 * lift, aL1: 28 + 2 * lift, aL2: -92 - 47 * lift, aR1: -28 - 2 * lift, aR2: 92 + 47 * lift, bob: -4 * lift }} />
                <div style={{ position: 'absolute', left: 150 - 95, top: 300 - 60 * lift - 66 }}>
                  <BookOpen size={190} open={open} glow={0.6 * open} />
                </div>
              </div>
              <div style={{ position: 'absolute', right: 120, top: 70, transform: `scale(${cp}) translateY(${idle(F, 4, 4, 50)}px)` }}>
                <Compass size={170} rot={rot} lock={lock} />
              </div>
            </Card>
          </Abs>
          <Abs y={950}><Small F={F} at={2710} text="একজন প্রকৃত মুসলিমের" size={64} /></Abs>
          <Abs y={1058}><Key F={F} at={2747} text="আসল মিশন" size={110} /></Abs>
          <Abs y={1200}>
            <KBlock>
              <Key F={F} at={2779} text="সবার আগে জ্ঞান অর্জন!" v="teal" size={86} underline />
            </KBlock>
            <div style={{ position: 'absolute', top: 140, left: '50%', height: 6, width: 980 * ulGrow, transform: 'translateX(-50%)', background: C.goldDeep, borderRadius: 3, opacity: ulGrow }} />
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
