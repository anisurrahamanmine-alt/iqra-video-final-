import React from 'react';
import { AbsoluteFill } from 'remotion';
import { idle, lin, ramp, rnd, sp } from '../anim';
import { sc } from '../config';
import { SfxCue, sx } from '../sfx';
import { C, FONT, SHADOW } from '../theme';
import { Abs } from '../components/Card';
import { BellIcon, Cursor, ShareIcon, ThumbUp } from '../components/Icons';
import { Key, Pill } from '../components/Kinetic';
import { SceneShell } from '../components/SceneShell';

const S = sc(11);
// cues: ভিডিওটি 2852 · লাইক 2944 · শেয়ার 2954 · সাবস্ক্রাইব 2973 · ফলো 3002 · সাথেই 3019
export const SFX11: SfxCue[] = [
  sx(2852, 'shine.mp3', 0.1, 60), sx(2864, 'paper_slide.mp3', 0.13), sx(2882, 'synth_chime_soft.wav', 0.1, 45), sx(2940, 'pop_a.mp3', 0.12),
  sx(2957, 'ui_click.mp3', 0.26), sx(2973, 'ui_tap.mp3', 0.18), sx(3004, 'ui_tap.mp3', 0.26), sx(3020, 'marker.mp3', 0.13),
  sx(3028, 'bell.mp3', 0.12, 52),
];

const Sky: React.FC<{ F: number }> = ({ F }) => {
  const sun = ramp(F, 2850, 3080);
  return (
    <div style={{ position: 'absolute', left: -140, top: -140, width: 1360, height: 2200, overflow: 'hidden', background: 'linear-gradient(180deg, #141E30 0%, #1C3A5A 30%, #146B73 55%, #5FB8A4 72%, #F6D98B 88%, #FDE68A 100%)' }}>
      <div style={{ position: 'absolute', left: 680 - 520, top: 1880 - 220 * sun, width: 1040, height: 620, borderRadius: '50%', background: 'radial-gradient(ellipse at center, #FFF6D5 0%, #FDE68Acc 30%, #FDE68A00 70%)' }} />
      {Array.from({ length: 26 }).map((_, i) => {
        const x = rnd(i + 1) * 1340, y = rnd(i + 40) * 900;
        const tw = 0.35 + 0.45 * Math.sin((F + i * 17) / 18);
        const s = 10 + rnd(i + 3) * 16;
        return (
          <svg key={i} width={s} height={s} viewBox="0 0 100 100" style={{ position: 'absolute', left: x, top: y + idle(F, i, 4, 90), opacity: tw }}>
            <g transform="translate(50 50)" fill="#FDE68A"><rect x={-26} y={-26} width={52} height={52} /><rect x={-26} y={-26} width={52} height={52} transform="rotate(45)" /></g>
          </svg>
        );
      })}
      {/* faint geometric lattice */}
      <svg width={1360} height={2200} style={{ position: 'absolute', inset: 0, opacity: 0.08 }}>
        <defs><pattern id="skyl" width={180} height={180} patternUnits="userSpaceOnUse"><g transform="translate(90 90)" fill="none" stroke="#FDE68A" strokeWidth={1.2}><rect x={-44} y={-44} width={88} height={88} /><rect x={-44} y={-44} width={88} height={88} transform="rotate(45)" /></g></pattern></defs>
        <rect width={1360} height={2200} fill="url(#skyl)" transform={`translate(${-(F * 0.2) % 180} 0)`} />
      </svg>
    </div>
  );
};

const Btn: React.FC<{ F: number; at: number; hot: number; w: number; icon: React.ReactNode; label: string; teal?: boolean }> = ({ F, at, hot, w, icon, label, teal }) => {
  const p = sp(F, at, 'pop');
  const h = hot > 0 ? lin(F, hot, hot + 4) * (1 - lin(F, hot + 22, hot + 34)) : 0;
  return (
    <div style={{ width: w, height: 120, borderRadius: 60, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, background: teal ? C.teal : h > 0.3 ? C.gold : '#FFFFFF', border: `2px solid ${teal ? C.teal : C.hair}`, boxShadow: teal ? '0 10px 24px rgba(13,148,136,.35)' : SHADOW.soft, opacity: lin(F, at, at + 6), transform: `translateY(${40 * (1 - p)}px) scale(${(0.7 + 0.3 * p) * (1 + 0.06 * h)})` }}>
      {icon}
      <span style={{ fontFamily: FONT.sans, fontWeight: 700, fontSize: 48, color: teal ? '#FFFFFF' : C.navy, whiteSpace: 'nowrap' }}>{label}</span>
    </div>
  );
};

export const Scene11: React.FC = () => (
  <SceneShell from={S.from} to={S.to} enter="fade" exit="none">
    {(F) => {
      const cp = sp(F, 2862, 'soft');
      const ar = ramp(F, 2880, 2896);
      const bar = sp(F, 2940, 'pop');
      // cursor path: share (2956) then subscribe (3004)
      const cur1 = ramp(F, 2944, 2955), cur2 = ramp(F, 2990, 3002);
      const cx = 820 + (520 - 820) * cur1 + (800 - 520) * cur2;
      const cy = 1080 + (900 - 1080) * cur1;
      const press = (t: number) => (F >= t && F < t + 14 ? [1, 0.9, 1.08, 1][Math.min(3, Math.floor((F - t) / 4))] : 1);
      const ripple = (t: number) => ramp(F, t, t + 22);
      const shimmer = ramp(F, 2985, 3010);
      return (
        <>
          <Sky F={F} />
          {/* top-centre hero card */}
          <Abs y={420} style={{ opacity: lin(F, 2862, 2870), transform: `translate(-50%, -50%) translateY(${80 * (1 - cp) + idle(F, 0, 3, 70)}px) scale(${0.92 + 0.08 * cp})` }}>
            <div style={{ width: 860, padding: '26px 40px 34px', borderRadius: 26, background: '#FFFEFA', border: `2px solid ${C.goldDeep}66`, boxShadow: '0 24px 60px rgba(0,0,0,.28)', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <div dir="rtl" lang="ar" style={{ unicodeBidi: 'embed', fontFamily: "'Amiri V', 'Amiri Quran V', serif", fontWeight: 700, fontSize: 120, lineHeight: 1.6, color: C.navy, clipPath: `inset(0 0 0 ${100 - ar * 100}%)`, textShadow: `0 0 30px ${C.gold}` }}>اقْرَأْ</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginTop: -10, opacity: lin(F, 2896, 2904) }}>
                <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 84, color: C.teal }}>ইকরা</span>
                <span style={{ width: 40, height: 6, borderRadius: 3, background: C.goldDeep }} />
                <span style={{ fontFamily: FONT.display, fontWeight: 800, fontSize: 84, color: C.navy, background: C.gold, borderRadius: 14, padding: '0 18px' }}>পড়ো</span>
              </div>
              <div style={{ marginTop: 12, fontFamily: FONT.sans, fontWeight: 600, fontSize: 46, color: C.ink, opacity: lin(F, 2912, 2920), transform: `translateY(${16 * (1 - lin(F, 2912, 2920))}px)` }}>ইসলামের সর্বপ্রথম নির্দেশ</div>
              <div style={{ fontFamily: FONT.sans, fontWeight: 600, fontSize: 46, color: C.teal, opacity: lin(F, 2924, 2932), transform: `translateY(${16 * (1 - lin(F, 2924, 2932))}px)` }}>জ্ঞানের আলোয় আলোকিত হোন</div>
            </div>
          </Abs>
          {/* CTA action bar */}
          <Abs y={900} style={{ opacity: lin(F, 2940, 2946), transform: `translate(-50%, -50%) translateY(${60 * (1 - bar)}px)` }}>
            <div style={{ position: 'relative', display: 'flex', gap: 22, padding: 22, borderRadius: 80, background: 'rgba(255,254,250,.96)', boxShadow: '0 20px 50px rgba(0,0,0,.25)', overflow: 'hidden' }}>
              <Btn F={F} at={2942} hot={2944} w={230} label="লাইক" icon={<ThumbUp size={52} />} />
              <div style={{ position: 'relative', transform: `scale(${press(2956)})` }}>
                <Btn F={F} at={2948} hot={0} w={250} teal label="শেয়ার" icon={<ShareIcon size={50} />} />
                <div style={{ position: 'absolute', left: '50%', top: '50%', width: 300 * ripple(2956), height: 300 * ripple(2956), borderRadius: '50%', border: `4px solid ${C.teal}`, transform: 'translate(-50%, -50%)', opacity: 1 - ripple(2956) }} />
              </div>
              <div style={{ position: 'relative', transform: `scale(${press(3004)})` }}>
                <Btn F={F} at={2954} hot={2973} w={320} label="সাবস্ক্রাইব" icon={<BellIcon size={50} />} />
                <div style={{ position: 'absolute', left: '50%', top: '50%', width: 340 * ripple(3004), height: 340 * ripple(3004), borderRadius: '50%', border: `4px solid ${C.goldDeep}`, transform: 'translate(-50%, -50%)', opacity: 1 - ripple(3004) }} />
              </div>
              <div style={{ position: 'absolute', top: 0, bottom: 0, width: 140, left: -200 + 1100 * shimmer, background: 'linear-gradient(100deg, transparent, rgba(255,255,255,.75), transparent)', opacity: shimmer > 0 && shimmer < 1 ? 1 : 0 }} />
            </div>
            <div style={{ marginTop: 14, fontFamily: FONT.sans, fontWeight: 600, fontSize: 40, color: '#FFFFFF', opacity: lin(F, 3002, 3010), textShadow: '0 2px 10px rgba(0,0,0,.4)' }}>বা ফলো করুন</div>
          </Abs>
          {/* cursor */}
          <div style={{ position: 'absolute', left: cx, top: cy, opacity: lin(F, 2944, 2950) * (1 - lin(F, 3014, 3022)), transform: `scale(${F >= 2955 && F < 2961 ? 0.85 : F >= 3002 && F < 3008 ? 0.85 : 1})` }}><Cursor size={74} /></div>
          {/* final lock-up */}
          <Abs y={1170}>
            <Pill style={{ opacity: lin(F, 3017, 3023), padding: '14px 50px' }}>
              <Key F={F} at={3017} text="সাথেই থাকুন!" size={100} underline />
            </Pill>
          </Abs>
        </>
      );
    }}
  </SceneShell>
);
