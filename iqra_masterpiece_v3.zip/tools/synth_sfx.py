import numpy as np, scipy.signal as sg, scipy.io.wavfile as wf, sys
SR=48000; out=sys.argv[1]
def save(n,x):
    x=x/np.max(np.abs(x))*10**(-3/20)
    f=int(.008*SR); x[:f]*=np.linspace(0,1,f); x[-f*3:]*=np.linspace(1,0,f*3)
    wf.write(f"{out}/{n}.wav",SR,(x*32767).astype(np.int16))
t=lambda d:np.arange(int(d*SR))/SR
rng=np.random.default_rng(7)
# soft spiritual chime: harmonic sines, slow decay, gentle shimmer
T=t(2.6); x=np.zeros_like(T)
for f,a,d in [(523.25,1,1.6),(783.99,.6,1.3),(1046.5,.45,1.0),(1567.98,.2,.7),(2093,.12,.5)]:
    x+=a*np.sin(2*np.pi*f*T+0.3*np.sin(2*np.pi*4*T))*np.exp(-T/d)
x*=np.minimum(1,T/0.01); save('synth_chime_soft',x)
# tick: click + resonance
T=t(0.09); x=np.sin(2*np.pi*2600*T)*np.exp(-T/0.012)+0.5*rng.standard_normal(len(T))*np.exp(-T/0.002); save('synth_tick',x)
# slash: bandpassed noise sweep 0.22s
T=t(0.24); n=rng.standard_normal(len(T)); b,a=sg.butter(2,[1500/(SR/2),9000/(SR/2)],'band'); n=sg.lfilter(b,a,n)
env=np.sin(np.pi*np.minimum(1,T/0.24))**2; save('synth_slash',n*env)
# sunrise swell: major chord pad rising 3s
T=t(3.6); x=np.zeros_like(T)
for f in [261.63,329.63,392.0,523.25]:
    x+=np.sin(2*np.pi*f*T)+0.3*np.sin(2*np.pi*2*f*T)
env=np.minimum(1,T/2.2)**1.5*np.minimum(1,(3.6-T)/0.9); b,a=sg.butter(2,2500/(SR/2)); save('synth_swell',sg.lfilter(b,a,x*env))
# soft riser (low) 2.2s
T=t(2.2); n=rng.standard_normal(len(T)); fc=np.linspace(300,2400,len(T)); y=np.zeros_like(n); 
for i in range(0,len(n),2400):
    b,a=sg.butter(2,fc[i]/(SR/2)); y[i:i+2400]=sg.lfilter(b,a,n[i:i+2400])
y+=0.4*np.sin(2*np.pi*np.cumsum(np.linspace(80,220,len(T)))/SR)
save('synth_riser_soft',y*(T/2.2)**2)
