import re, json, subprocess, sys
srt_path, audio, out_dir = sys.argv[1], sys.argv[2], sys.argv[3]
txt = open(srt_path, encoding='utf-8-sig').read().replace('\r\n','\n')
def ts(t):
    h,m,r = t.split(':'); s,ms = r.split(','); return int(h)*3600+int(m)*60+int(s)+int(ms)/1000
cues=[]
for b in re.split(r'\n\s*\n', txt.strip()):
    L=b.strip().split('\n')
    if len(L)<3: continue
    a,c=L[1].split(' --> ')
    cues.append(dict(i=int(L[0]),s=ts(a),e=ts(c),text=' '.join(L[2:])))
# corrections (word-level, level A)
CORR = {
 ('কোনটাই',):'কোনোটাই',
 ('কোন',):'কোনো',
 ('important',):'ইম্পর্টেন্ট',
 ('যাকে',):'যাঁকে',
}
log=[]
def fix(text,ci,t):
    ws=text.split(' ')
    out=[]
    j=0
    while j<len(ws):
        w=ws[j]
        core=re.sub(r'[।,?!]','',w)
        if core=='বিসমিরব্বিকাল্লাজি':
            out+=['বিসমি','রব্বিকাল্লাজি']; log.append(dict(cue=ci,time=round(t,2),before=w,after='বিসমি রব্বিকাল্লাজি',proof='আরবি বাক্যের প্রতিবর্ণ; দুই আরবি শব্দ আলাদা',level='A')); j+=1; continue
        if core=='জীবন' and j+1<len(ws) and ws[j+1].startswith('ব্যবস্থার'):
            out.append('জীবনব্যবস্থার'); log.append(dict(cue=ci,time=round(t,2),before='জীবন ব্যবস্থার',after='জীবনব্যবস্থার',proof='প্রমিত বানান; প্রম্পটে একই',level='A')); j+=2; continue
        for k,v in CORR.items():
            if core==k[0]:
                nw=w.replace(core,v); log.append(dict(cue=ci,time=round(t,2),before=w,after=nw,proof='প্রম্পটের লেখা/প্রমিত বানান',level='A')); w=nw; break
        out.append(w); j+=1
    return ' '.join(out)
for c in cues: c['fixed']=fix(c['text'],c['i'],c['s'])
# silences
r=subprocess.run(['ffmpeg','-i',audio,'-af','silencedetect=noise=-32dB:d=0.12','-f','null','-'],capture_output=True,text=True).stderr
st=[float(x) for x in re.findall(r'silence_start: ([0-9.]+)',r)]; en=[float(x) for x in re.findall(r'silence_end: ([0-9.]+)',r)]
sil=list(zip(st,en))
words=[]
for c in cues:
    # speech intervals in cue
    segs=[[c['s'],c['e']]]
    for a,b in sil:
        ns=[]
        for s,e in segs:
            if b<=s or a>=e: ns.append([s,e]); continue
            if a>s: ns.append([s,a])
            if b<e: ns.append([b,e])
        segs=[x for x in ns if x[1]-x[0]>0.05]
    total=sum(e-s for s,e in segs)
    ws=c['fixed'].split(' ')
    wts=[len(re.sub(r'[।,?!]','',w))+1.5 for w in ws]
    W=sum(wts); acc=0
    def at(x):
        x*=total
        for s,e in segs:
            if x<=e-s: return s+x
            x-=e-s
        return segs[-1][1]
    for w,wt in zip(ws,wts):
        s=at(acc/W); acc+=wt; e=at(acc/W)
        words.append(dict(w=w,s=round(s,3),e=round(e,3),cue=c['i']))
# anchor sentence ends (।?!,) to nearest silence start within 0.9s, re-distribute in between
import bisect
def realign(words):
    anchors=[(-1,None)]
    for i,w in enumerate(words):
        if re.search(r'[।?!,]$',w['w']):
            best=None
            for a,b in sil:
                if abs(a-w['e'])<0.9 and (best is None or abs(a-w['e'])<abs(best[0]-w['e'])): best=(a,b)
            if best and best[0]>w['s']-0.6: anchors.append((i,best))
    out=[dict(x) for x in words]
    for k in range(1,len(anchors)):
        i0=anchors[k-1][0]+1; i1=anchors[k][0]; a,b=anchors[k][1]
        t0 = anchors[k-1][1][1] if anchors[k-1][1] else words[i0]['s']
        if i1<i0: continue
        seg=words[i0:i1+1]; T0=seg[0]['s']; T1=seg[-1]['e']
        if T1-T0<=0.1: continue
        n0=max(t0,T0 if anchors[k-1][1] is None else t0); n1=a
        if n1-n0<0.2: continue
        for j,w in enumerate(seg):
            f=lambda t:n0+(t-T0)/(T1-T0)*(n1-n0)
            out[i0+j]['s']=round(f(w['s']),3); out[i0+j]['e']=round(f(w['e']),3)
        # next word starts at silence end
    return out
words=realign(words)
json.dump(words,open(out_dir+'/words.json','w'),ensure_ascii=False,indent=0)
json.dump(log,open(out_dir+'/corrections.json','w'),ensure_ascii=False,indent=1)
def fmt(t):
    ms=int(round(t*1000)); return '%02d:%02d:%02d,%03d'%(ms//3600000,ms//60000%60,ms//1000%60,ms%1000)
with open(out_dir+'/corrected.srt','w',encoding='utf-8') as f:
    for c in cues:
        f.write(f"{c['i']}\n{fmt(c['s'])} --> {fmt(c['e'])}\n{c['fixed']}\n\n")
for i,w in enumerate(words): print(i,w['w'],w['s'],w['e'])
print(len(log),'corrections')
